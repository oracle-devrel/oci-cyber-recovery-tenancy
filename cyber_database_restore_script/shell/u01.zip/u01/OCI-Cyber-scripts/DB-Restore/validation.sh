#!/bin/bash
###########################################################################################
# $Header: validation.sh v0.1 2022/12/14 05:24:41 vivaturi - Validation Script $
#
# NAME
#   validation.sh 
# FUNCTION
#   This script will call the main validation script which is executed as oracle user
# NOTES
# MODIFIED
############################################################################################
sudo -u oracle sh /u01/OCI-Cyber-scripts/DB-Restore/db/validation.sql > /u01/OCI-Cyber-scripts/DB-Restore/validation.out
