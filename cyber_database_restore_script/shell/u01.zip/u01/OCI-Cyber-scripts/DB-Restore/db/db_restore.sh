#!/bin/bash
#######################################################################################
# $Header: db_restore.sh v0.1 2023/02/02 05:24:41 vivaturi - DB Restore $
#
# NAME
#   db_restore.sh
# FUNCTION
#   This script will restore the control file, restore & recover the database using standby db backup. 
#   This script is executed as a oracle user and needs to be updated as per your environment.
# UPDATE The Script as per your environment.
#   1) Update the environment file name and path which needs to be sourced.
#   2) Make sure we have the required pfile in place to start the DB in nomount. 
#   3) Update the DBSID.
#   4) Disk Group name at set newname for database line. 
# NOTES
# MODIFIED
########################################################################################
# User specific aliases and functions
. /home/oracle/DB.env
sqlplus -s "/ as sysdba" << EOF
startup nomount pfile='/u01/OCI-Cyber-scripts/DB-Restore/db/pfile.ora';
create spfile='+DATA' from pfile='/u01/OCI-Cyber-scripts/DB-Restore/db/pfile.ora';
startup nomount force;
EOF
rman target / << EOF
run
{
set DBID <Update the DB ID Value>;
ALLOCATE CHANNEL SBT1 DEVICE TYPE SBT parms='SBT_LIBRARY=/u01/OCI-Cyber-scripts/DB-Restore/opc/lib/libopc.so, ENV=(OPC_PFILE=/u01/OCI-Cyber-scripts/DB-Restore/opc/opcCRS.ora)' ;
restore PRIMARY controlfile from AUTOBACKUP maxdays 20;
alter database mount;
}
EOF
sqlplus -s "/ as sysdba" << EOF
alter database disable block change tracking;
alter database set standby to maximize performance;
EOF
srvctl status database -d $ORACLE_UNQNAME
sqlplus -S "/ as sysdba" << EOF > /u01/OCI-Cyber-scripts/DB-Restore/db/current_seq.log
set head off
set echo off
set feedback off
select 'set until sequence ' || seq# || ' thread ' || thread# || '; ' "Recover Command"
from (
select * from (
select thread#, sequence# seq#, next_change# from (
select * from v\$backup_archivelog_details
where thread# || '_' || sequence# in
(select thread# || '_' || max(sequence#) from v\$backup_archivelog_details group by thread#)
) order by next_change#
) where rownum = 1 ) ;
EOF
echo "run" > /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
echo "{" >> /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
echo "ALLOCATE CHANNEL CH1 DEVICE TYPE SBT parms='SBT_LIBRARY=/u01/OCI-Cyber-scripts/DB-Restore/opc/lib/libopc.so, ENV=(OPC_PFILE=/u01/OCI-Cyber-scripts/DB-Restore/opc/opcCRS.ora)';" >> /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
echo "ALLOCATE CHANNEL CH2 DEVICE TYPE SBT parms='SBT_LIBRARY=/u01/OCI-Cyber-scripts/DB-Restore/opc/lib/libopc.so, ENV=(OPC_PFILE=/u01/OCI-Cyber-scripts/DB-Restore/opc/opcCRS.ora)';" >> /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
echo "ALLOCATE CHANNEL CH3 DEVICE TYPE SBT parms='SBT_LIBRARY=/u01/OCI-Cyber-scripts/DB-Restore/opc/lib/libopc.so, ENV=(OPC_PFILE=/u01/OCI-Cyber-scripts/DB-Restore/opc/opcCRS.ora)';" >> /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
echo "ALLOCATE CHANNEL CH4 DEVICE TYPE SBT parms='SBT_LIBRARY=/u01/OCI-Cyber-scripts/DB-Restore/opc/lib/libopc.so, ENV=(OPC_PFILE=/u01/OCI-Cyber-scripts/DB-Restore/opc/opcCRS.ora)';" >> /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
echo "set newname for database to '+DATA'; " >> /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
cat /u01/OCI-Cyber-scripts/DB-Restore/db/current_seq.log >> /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
echo "restore database;" >> /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
echo "switch datafile all;" >> /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
echo "recover database;" >> /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
echo "}" >> /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
chmod +x /u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh
rman target / cmdfile=/u01/OCI-Cyber-scripts/DB-Restore/db/rman_restore.sh log=/u01/OCI-Cyber-scripts/DB-Restore/db/logs/rman_restore_`date +%Y%m%d%H%M%S`.log
sqlplus -s "/ as sysdba" << EOF
alter database set standby to maximize performance;
alter database open resetlogs;
EOF
srvctl stop database -d $ORACLE_UNQNAME
srvctl start database -d $ORACLE_UNQNAME -o "read only"
srvctl status database -d $ORACLE_UNQNAME -v
