#!/bin/bash
#######################################################################################
# $Header: db_asm_rm.sh v0.1 2023/02/02 05:24:41 vivaturi - Remove ASM files $
#
# NAME
#   db_asm_rm.sh
# FUNCTION
#   This script will delete all the ASM DATA & RECO files
#   This script is executed as a grid user and needs to be updated as per the disk group names.
# UPDATE The Script as per your environment.
#   1) Update with the absolute path details for Oracle Home, if there is any change with your envirnomnet. 
#   2) Update the DB Unique name
#   3) Update the hostname
# NOTES
# MODIFIED
########################################################################################
PATH=/sbin:/bin:/usr/sbin:/usr/bin:/u01/app/19.0.0.0/grid/bin:/u01/app/19.0.0.0/grid/OPatch; export PATH
ORACLE_SID=+ASM1; export ORACLE_SID
ORACLE_HOSTNAME=<hostname>; export ORACLE_HOSTNAME
LD_LIBRARY_PATH=/u01/app/19.0.0.0/grid/lib; export LD_LIBRARY_PATH
OH=/u01/app/19.0.0.0/grid; export OH
ORACLE_HOME=/u01/app/19.0.0.0/grid; export ORACLE_HOME
asmcmd rm -r +DATA1/<DB_UNIQUE_NAME>/*  
asmcmd rm -r +RECO1/<DB_UNIQUE_NAME>/*
