#!/bin/bash
#######################################################################################
# $Header: db_shut.sh v0.1 2023/02/02 15:02:30 vivaturi - Shutdown Database $
#
# NAME
#   db_shut.sh
# FUNCTION
#   This script will shut down the database before it's been removed
#   This script is executed as a oracle user, update the DB.env as per your environment
# NOTES
# MODIFIED
########################################################################################
#Source the DB env
. /home/oracle/DB.env
srvctl stop database -d $ORACLE_UNQNAME
