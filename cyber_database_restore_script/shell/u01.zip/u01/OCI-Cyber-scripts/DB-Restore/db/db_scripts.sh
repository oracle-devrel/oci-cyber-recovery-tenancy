#!/bin/bash
#######################################################################################
# $Header: db_scripts.sh v0.1 2023/02/02 15:02:30 vivaturi - DB Restore $
#
# NAME
#   db_scripts.sh
# FUNCTION
#   This script will call other scripts to perform the below task 
#    1. Shutdown the Database
#    2. Remove the datafiles from ASM
#    3. Restore the database
# NOTES
# MODIFIED
########################################################################################
#1. Shutdown Database
#script to shutdown database as oracle user 
sudo -u oracle sh -x /u01/OCI-Cyber-scripts/DB-Restore/db/db_shut.sh
#2. Remove the datafiles from ASM
#script to remove all the files from ASM as grid user
sudo -u grid sh -x /u01/OCI-Cyber-scripts/DB-Restore/db/db_asm_rm.sh
#3. Restore the database
#sctipt to restore database
sudo -u oracle sh -x /u01/OCI-Cyber-scripts/DB-Restore/db/db_restore.sh
echo "**** Restore Completed ****" 
