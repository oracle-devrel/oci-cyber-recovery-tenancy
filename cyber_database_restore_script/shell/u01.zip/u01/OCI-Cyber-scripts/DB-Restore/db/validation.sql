#!/bin/bash
###########################################################################################
# $Header: validation.sql v0.1 2022/12/14 05:24:41 vivaturi - DB Restore $
#
# NAME
#   validation.sql 
# FUNCTION
#   This script runs the EBS validation queries connected as sysdba. 
# NOTES
# MODIFIED
#    vivaturi   14/12/22  - 20221214 - inital version
############################################################################################
# User specific aliases and functions
#
# Source the DB envirnomnet
#
. /home/oracle/DB.env
ORACLE_PDB_SID=PDBSID; export ORACLE_PDB_SID
#
#echo "Validation Report of EBS Database"
#echo "================================="
#
sqlplus -s "/ as sysdba" << EOF
set echo off
set verify off
set feedback off
set heading off
set trimspool on
#set termout off

col Distinct_Datafile_Status for a24
col Distinct_Tablespaces_Status for a27
col Distinct_Tempfiles_Status for a25
col Distinct_Datafiles_Status for a25
SET NUMWIDTH 20

select 'pdb:'||PDB_NAME from dba_pdbs;
select 'Sysdate:'||sysdate from dual;
select 'DB_Name:'||name from v\$database;
select 'Open_Mode:'||open_mode from v\$database;
select 'Status:'||status from v\$instance;
select 'Current_scn:'||current_scn from v\$database;
select 'Database_Status:'||database_status from v\$instance;
select 'Logins:'||logins from v\$instance;
select distinct 'Distinct_Datafile_Status:'||status from v\$datafile;
select distinct 'Distinct_Tablespaces_Status:'||status from dba_Tablespaces;
select distinct 'Distinct_Tempfiles_Status:'||status from dba_data_files;
select distinct 'Distinct_Datafiles_status:'||status from dba_temp_files;
select 'Invalids:'||count(*) from dba_objects where status='INVALID';
select 'Recover_Files:'||count(*) from v\$recover_file;

EOF

