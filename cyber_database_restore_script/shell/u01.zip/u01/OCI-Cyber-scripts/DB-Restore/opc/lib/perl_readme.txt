Backup on the Oracle Cloud - Using the Oracle Database Cloud Backup Utility
Tools 

This is the README file for utility tool scripts that support 
Oracle Database Cloud Backup Module to back up an Oracle database to
Oracle Database Backup Service (ODBS) (also referred to as
 Oracle Public Cloud (OPC) in this document).

--------------------------------------------------------------------
I. What you need to have before starting the installation

Using these tools require an Oracle Database Backup
Service account, and the software library and associated
files. Before you run the tool, verify that you have:

1. Your Oracle Database Backup Service Username, Password
   and Hostname

   You obtain these credentials at https://cloud.oracle.com.

2. The perl script: bulkimport.pl

   The installer will download the scripts together with the 
   library. 

4. Perl 5 on the computer where the tools will run.

5. Database Version Support: The Oracle Database Cloud Backup Module
   can be used to backup the following supported versions of Oracle
   Database: Oracle Database 10g Release 2 or higher.

6. bulkimport.pl requires a running Oracle Database to perform its
   functionality. Oracle Database Cloud Backup Module must be installed 
   and configured properly. 

7. The scripts do not support Windows platform.


--------------------------------------------------------------------
II. User Guide for bulkimport.pl, options description 

Bulkimport.pl is a perl based tool that facilitates the process of
importing and cataloging disk backups to OPC backups.

Execute the script supplying all the mandatory parameters in one
line, each double-hyphen-preceded label followed by '=' and its value
(if a value is required).

First run the script with help option or without any parameters:

 % perl bulkimport.pl --help 

to get a usage message, whose parameters are explained below. From
the preceding section, you should have the values for all the
mandatory parameters. Ensure you have perl 5 correctly defined.  

    --host:          Host name for the Oracle Public Cloud account.
                 
The host path is mandatory.
https://[IdentityDomain].storage.oraclecloud.com/v1/[IdentityDomain]
[ServiceName]-[IdentityDomain].

   --credential:          The useranme/password
                          for the Oracle Public Cloud account

The OPC credentials are mandatory.

   --configFile:   File name of config file

The location where the OPC backup module configuration file will reside. 
If omitted, the installer will create the configuration file and place it in a
default system-dependent location. Optional. 

Default Unix location:    $ORACLE_HOME/dbs/opc<ORACLE_SID>.ora
Default Windows location: $ORACLE_HOME\database\opc<ORACLE_SID>.ora

   --libdir:      Directory to store library

The location where the library is placed. 

    --container:     OPC container to store backups

The name of the container to store backups. The container name is mandatory. 

   --user:          The useranme/password
                    of Oracle Database credential 

This is the connect string to login RMAN. If omitted, default "/" will
be used.

   --prefix:        The user defined file name prefix of all
                    uploaded backup pieces. 

If not specified, all files under the specified container are assumed
to be imported.

   --export/catalog: Specifies export and/or catalog operation that needs to
                     be performed. If omitted, both will be exeucted. 

--------------------------------------------------------------------
III. User Guide for bulkimport.pl: imports and catalogs the uploaded disk
     backups 

Before executing bulkimport.pl, you need to have a series of RMAN
disk backups on hand that are ready to be imported and cataloged in
OPC.

Rename all your backup pieces with some common prefix, the prefix
must be unique, such that the batch job won't confuse with existing files
in the OPC container. 

Upload all your backup pieces to cloud storage. You can use curl or 
any other approriate tool to do the job.

for example:
curl -u user/passwd -T yourprefix-backupfile-name
https://storage.oraclecorp.com/v1/domainname 

NOTE: Oracle Cloud Starge has limits on the size of uploaded files.
Check https://docs.oracle.com/en/cloud/iaas/storage-cloud/cssto/toc.html
for details on how to upload large objects and how to upload multiple objects
in a single operation.

Execute bulkimport.pl:
perl bulkimport.pl --credentials=username/passwd
--host=https://storage.oraclecorp.com/v1/domainame
--container=backup --prefix=yourprefix
--libdir=/orclhome/bin
--configfile=/orclhome/dbs/opct1.ora

This will both export and catalog your backups in OPC SBT backups.

