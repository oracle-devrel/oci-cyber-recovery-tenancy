# 
# $Header: rdbms/admin/odbsrmt.py /main/3 2020/05/28 23:45:17 hnamachi Exp $
#
# odbsrmt.py
# 
# Copyright (c) 2016, 2020, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      odbsrmt.py - Oracle Database Backup Service Reporting and 
#                   Maintenance Tool 
#
#    DESCRIPTION
#      This tool is used to generate backup reports/and perform
#      cloud backup maintenance.
#
#
#    MODIFIED   (MM/DD/YY)
#    hnamachi  05/13/20 - Bug 31300790 : prompt for credentials
#    lexuxu    07/04/18 - Creation


import xml.etree.ElementTree as ET
import httplib
import base64
import sys
import os
import threading
import Queue
import datetime
import urlparse
import argparse
import re
import getpass
import urllib
import json
import time
from email.utils import formatdate

RETRY = 3
LIMIT = 10000
BMC_LIMIT = 1000
DEL_LIMIT = 100
LIST_TIMEOUT = 120
DOWNLOAD_TIMEOUT = 120
RECALL_TIMEOUT = 60
DEL_TIMEOUT = 120
BMC_DEL_TIMEOUT = 60
CHECK_STATUS_PAUSE = 30
MAX_CHECK_ROUND = 100

# class object stores OCI-C/OCI-swift credential info
class Cred():
    def __init__(self):
        self.username = None
        self.password = None
        self.token    = None
        self.keyid    = None
        self.pvtkey   = None

    def readpvtkey(self, ctx):
        filename = ctx.pvtkeyfile
        with open(filename, "r") as pvtfh:
            self.pvtkey = RSA.importKey(pvtfh.read())

    def setkeyid(self, ctx):
        uocid = ctx.uocid
        tocid = ctx.tocid
        fingerprint = p.fingerprint
        self.keyid = "%s/%s/%s" % (tocid, uocid, fingerprint)

    def settoken(self, token):
        self.token = token

    def setuserpwd(self, usrname, pwd):
        self.username = usrname
        self.password = pwd

    def isbmcbased(self):
        if self.keyid is not None:
            return True
        else:
            return False

    def istokenbased(self):
        if self.token is not None:
            return True
        else:
            return False

    def ispasswordbased(self):
        if self.password is not None and self.username is not None:
            return True
        else:
            return False

# class object stores argument properties
class Odbs_context():
    def __init__(self):
        self.headers = None
        self.cred = None
        self.container = None
        self.debug = False
        self.dir = None
        self.base = None
        self.forcename = None
        self.mode = None
        self.host = None
        self.exclude_deferred = False
        self.format = None
        self.bpprefix = None
        self.dbid = 0
        self.untildate = None
        self.thread = 1
        self.ocitype = None
        self.proxyhost = None
        self.proxyport = None
        self.ext = None
        self.uocid = None
        self.tocid = None
        self.fingerprint = None
        self.pvtkeyfile  = None
        self.namespace   = None
        self.skip_check_status = False

# class object stores archive storage recall job list info
class Jobelem():
    def __init__(self, con, chunkname, jobid):
        self.jobid = jobid
        self.container = con
        self.chunkname = chunkname

# class object stores archive storage recall job status info
class JobStatus():
    def __init__(self, con, chunkname, jobid, progress, completed, completed_percentage):
        self.jobid = jobid
        self.container = con
        self.chunkname = chunkname
        self.progress  = progress
        self.completed = completed
        self.completed_percentage = completed_percentage

# class object stores XML file path and its container name
class Bkplist():
    def __init__(self, name, con):
        self.piecename = name
        self.container = con

# class object stores detailed metadata of metadata.xml
class PieceMetaData():
    def __init__(self):
        self.container = None
        self.filename = None
        self.dbname = None
        self.dbid = None
        self.dbversion = None
        self.filesize = None
        self.lastmodified = None
        self.chunkprefix = None
        self.lastmodified = None
        self.backuptype = None
        self.incremental = None
        self.compressed = None
        self.encrypted = None
        self.setstamp = None
        self.setcount = None
        self.pieceno = None

# class object as context pointer for slave threads
#
# queue         - Queue of metadata.xml files, slave will
#                 consume this queue for downloading
# filehandle    - file handle of output file, only used when
#                 all outputs are directed to a common file
#                 (e.g. in report/rman-listfile mode)
# fhlock        - lock for sync filehandle
# loglock       - lock for calling log_msg in slave threads,
#                 to make STDOUT mesg in a coordinated manner
# calsize_queue - Queue that will store the sum of backups storage
#                 in each slave threads
# json_firstentry_flag
#               - a flag indicates if the current metadata is
#                 the first element in output file,
#                 (to make commas organized correctly in JSON)
#
class ThreadCtx():
    def __init__(self, queue, fh, calqueue):
        self.queue = queue
        self.filehandle = fh
        self.fhlock = threading.Lock()
        self.loglock = threading.Lock()
        self.calsize_queue = calqueue
        self.json_firstentry_flag = True # used to track if it's the first JSON element


def log_msg(text):
    print(text)


def validate_date(datestr):
    try:
        datetime.datetime.strptime(datestr, "%Y-%m-%d")
    except ValueError:
        log_msg("validate_date: Until date not valid")
        return 1
    return 0


#
# valid_log_dir - validate the directory for log file
#
# Parameters
#   - directory of log file
def valid_log_dir (dir):
    if dir == '':
        return 1
    if not os.path.isdir(dir):
        return 1
    if not os.access(dir, os.W_OK):
        return 1
    return 0


#
# get_login_string - construct the login credentials to get access
#                   to OPC containers
#  if the password is not specified explicitly, the user will need
#  to type it manually.
#
# Parameters
#   - OCI-Classic credential username/[password]
def get_login_string(credential):

    if credential is None:
      if sys.stdin.isatty():
         # Note: 'input()' needs to be used in python 3
         user = raw_input("Enter OPC Credential User: ")
      else:
         sys.stdout.write("Enter OPC Credential User: ")
         user = sys.stdin.readline().rstrip()
      pwd  = getpass.getpass("Enter OPC password:")
    elif re.match('.*/.*', credential):
        m = re.search('(.*)/(.*)', credential)
        user = m.group(1)
        pwd  = m.group(2)
    else:
        user = credential
        pwd  = getpass.getpass("Enter OPC password:")

    credx = Cred()
    credx.setuserpwd(user, pwd)
    return credx


#
# get_login_token - construct the login credentials with given token
#
#
# Parameters
#   - OCI auth token
def get_login_token(token):

    credx = Cred()
    credx.settoken(token)
    return credx


#
# get_login_keyid - construct the login credentials with given BMC
#                       credentials
#
#
# Parameters
#   - odbs context
# NOTE: details of BMC auth can be found from
# https://docs.cloud.oracle.com/iaas/Content/API/Concepts/
# signingrequests.htm?tocpath=Developer%20Tools%20%7CREST%20APIs%20%7C_____4
def get_login_keyid(p):

    credx = Cred()
    credx.setkeyid(p)
    credx.readpvtkey(p)
    return credx

#
# set_bmc_headers - set request headers including header signature
#
#
# Parameters
#   - odbs context
#   - request method
#   - netloc parameter
#   - path parameter
# NOTE: details of BMC auth can be found from
# https://docs.cloud.oracle.com/iaas/Content/API/Concepts/
# signingrequests.htm?tocpath=Developer%20Tools%20%7CREST%20APIs%20%7C_____4
def set_bmc_headers(p, method, netloc, path):

    cred = p.cred

    if path is None or path == "":
        path = "/"

    headers = {}
    headers["(request-target)"] = "%s %s" % (str.lower(method), path)
    headers["date"] = formatdate(timeval=None, localtime=False, usegmt=True)
    headers["host"] = netloc

    signing_str = ""
    signing_str = signing_str + "%s: %s\n" % ("(request-target)", headers["(request-target)"])
    signing_str = signing_str + "%s: %s\n" % ("date", headers["date"])
    signing_str = signing_str + "%s: %s\n" % ("host", headers["host"])
    signing_str = signing_str.strip()
    signing_str = signing_str.encode("ascii")

    rsa_obj = PKCS1_v1_5.new(cred.pvtkey)
    sha256_obj = SHA256.new()
    sha256_obj.update(signing_str)
    signed = rsa_obj.sign(sha256_obj)
    signature = base64.b64encode(signed).decode("ascii")

    #sig_maker = httpsig.Signer(secret=cred.pvtkey, algorithm='rsa-sha256')
    #signature = sig_maker.sign(signing_str)

    headers["Authorization"] = ("Signature version=\"1\"," +
                                "keyId=\"%s\",algorithm=\"rsa-sha256\"," % cred.keyid +
                                "headers=\"(request-target) date host\"," +
                                "signature=\"%s\"" % signature)

    return headers

#
# get_log_file_name - construct full base name with path
#
# Parameters
#   - log directory
#   - log base name
#   - debug flag
def get_log_file_name(dir, base, debug):

    if dir is None:
        dir = os.getcwd()
        if debug:
            log_msg("get_log_file_name: no log file directory " +
                    "was specified - using current dirctory %s" % dir)
    else:
        if debug:
            log_msg("get_log_file_name: log file directory = %s" % dir)

    return os.path.join(dir, base)

#
# cloud_validate - validate OCI host connectivity for OCI-classic/SWIFT
#                  GET namespace for BMC
#
# Parameters
#   - request header hash
#   - host name
#   - proxy host name
#   - proxy port number
#   - debug flag
def cloud_validate(p):

    for ii in range(0, RETRY):
        rc = opc_validate(p)
        if rc == 0:
            break
        elif ii < (RETRY -1):
            log_msg("cloud_validate: Failed to validate host, RETRYING...")

    return rc

#
# opc_validate - validate OCI host connectivity
#
# Parameters
#   - request header hash
#   - host name
#   - proxy host name
#   - proxy port number
#   - debug flag
def opc_validate(p):

    headers   = p.headers
    host      = p.host
    proxyhost = p.proxyhost
    proxyport = p.proxyport
    debug     = p.debug


    o = urlparse.urlparse(host)
    netloc = o.netloc
    path = o.path

    if proxyhost is None:
        conn = httplib.HTTPSConnection(netloc, timeout=LIST_TIMEOUT)
    else:
        conn = httplib.HTTPSConnection(proxyhost, proxyport,
                                       timeout=LIST_TIMEOUT)
        tunnel_header = {}
        #tunnel_header['Proxy-Connection'] = 'Keep-Alive'
        conn.set_tunnel(netloc, 443, tunnel_header)
        #headers['Host'] =netloc

    if debug:
       conn.set_debuglevel(2)

    # In case of BMC, header must be constructed separately
    # for each request
    if p.cred.isbmcbased():
       # GET BMC namespace
       path = "/n"
       headers = set_bmc_headers(p, "GET", netloc, path)
       conn.request("GET", path, None, headers)
    else:
       conn.request("HEAD", path, None, headers)

    r1 = conn.getresponse()
    if r1.status >= 400:
        log_msg("opc_validate: Error connecting " + netloc + path +
                ", status: " + str(r1.status))
        conn.close()
        return 1
    elif debug:
        log_msg("opc_validate: Requesting " + netloc + path +
                ", status: " + str(r1.status))

    if p.cred.isbmcbased():
        namespace = r1.read().strip('\"')
        p.namespace = namespace
        if debug:
            log_msg("opc_validate: BMC namespace is \"%s\"" % namespace)

    conn.close()

    return 0

#
# cloud_getnamespaceinfo - GET namespace info for BMC
#
# Parameters
#   - request header hash
#   - host name
#   - proxy host name
#   - proxy port number
#   - debug flag
def cloud_getnamespaceinfo(p):

    for ii in range(0, RETRY):
        rc = bmc_getnamespaceinfo(p)
        if rc == 0:
            break
        elif ii < (RETRY -1):
            log_msg("cloud_getnamespaceinfo: Failed to get BMC namespace info, RETRYING...")

    return rc

#
# bmc_getnamespaceinfo - validate OCI host connectivity
#
# Parameters
#   - request header hash
#   - host name
#   - proxy host name
#   - proxy port number
#   - debug flag
def bmc_getnamespaceinfo(p):

    host      = p.host
    proxyhost = p.proxyhost
    proxyport = p.proxyport
    debug     = p.debug

    if not p.cred.isbmcbased():
        return

    o = urlparse.urlparse(host)
    netloc = o.netloc

    if proxyhost is None:
        conn = httplib.HTTPSConnection(netloc, timeout=LIST_TIMEOUT)
    else:
        conn = httplib.HTTPSConnection(proxyhost, proxyport,
                                       timeout=LIST_TIMEOUT)
        tunnel_header = {}
        #tunnel_header['Proxy-Connection'] = 'Keep-Alive'
        conn.set_tunnel(netloc, 443, tunnel_header)
        #headers['Host'] = netloc

    # In case of BMC, header must be constructed separately
    # for each request
    # GET BMC namespace metadata
    path = "/n/%s" % p.namespace
    headers = set_bmc_headers(p, "GET", netloc, path)
    conn.request("GET", path, None, headers)

    r1 = conn.getresponse()
    if r1.status >= 400:
        log_msg("bmc_getnamespaceinfo: Error connecting " + netloc + path +
                ", status: " + str(r1.status))
        conn.close()
        return 1
    elif debug:
        log_msg("bmc_getnamespaceinfo: Requesting " + netloc + path +
                ", status: " + str(r1.status))

    metadata = json.loads(r1.read())
    #pprint.pprint(metadata)

    compartid = metadata.get('defaultSwiftCompartmentId')
    p.compartid = compartid
    if debug:
        log_msg("bmc_getnamespaceinfo: BMC namespace compartment ID is \"%s\"" % compartid)

    conn.close()

    return 0

#
# cloud_getcontainers- get list of container names under account
#
# Parameters
#   - odbs context 
#   - container list ptr
def cloud_getcontainers(p, containerlist):

    if not isinstance(containerlist, list):
        log_msg("cloud_getcontainers: Internal Error, NULL or " +
                "NON-LIST containerlist")
        exit(1)
    for ii in range(0, RETRY):
        del containerlist[:]
        rc = opc_getcontainers(p, containerlist)
        if rc == 0:
            break
        elif ii < (RETRY -1):
            log_msg("cloud_getcontainers: Failed to get container " +
                    "list, RETRYING...")

    return rc

#
# opc_getcontainers- get list of container names under account
#
# Parameters
#   - request header hash
#   - host name
#   - container list ptr
#   - debug flag
def opc_getcontainers(p, containerlist):

    headers = p.headers
    host    = p.host
    proxyhost = p.proxyhost
    proxyport = p.proxyport
    ocitype   = p.ocitype
    debug     = p.debug

    o = urlparse.urlparse(host)
    # marker is used in OCI-classic/SWIFT as a start
    # point of next list-bucket request
    # page is used in BMC as the next page
    # identifier for listing
    marker = None
    page   = None
    bmc_firstpage = True

    while True:

        if p.cred.isbmcbased():
            if page is None and not bmc_firstpage:
                break

        netloc = o.netloc
        path = o.path

        if proxyhost is None:
            conn = httplib.HTTPSConnection(netloc, timeout=LIST_TIMEOUT)
        else:
            conn = httplib.HTTPSConnection(proxyhost, proxyport,
                                           timeout=LIST_TIMEOUT)
            tunnel_header = {}
            #tunnel_header['Proxy-Connection'] = 'Keep-Alive'
            conn.set_tunnel(netloc, 443, tunnel_header)

        #if debug:
        #   conn.set_debuglevel(2)

        # In case of BMC, header must be constructed separately
        # for each request
        if p.cred.isbmcbased():
            # GET BMC namespace
            #path = "/n/%s/b" % p.namespace

            if bmc_firstpage:
                #path = path + "/?compartmentId=%s&limit=%d"
                # % (p.compartid, BMC_LIMIT)
                options = {'compartmentId': p.compartid, 'limit': BMC_LIMIT}

                # set bmc_firstpage to False
                bmc_firstpage = False
            else:
                #path = path + "/?compartmentId=%s&limit=%d&page=%s"
                # % (p.compartid, BMC_LIMIT, page)
                options = {'compartmentId': p.compartid, 'limit': BMC_LIMIT,
                           'page': page}

            #path = urllib.quote_plus(path, "/?=&")
            path = "/n/%s/b/?%s" % (urllib.quote_plus(p.namespace),
                                    urllib.urlencode(options))

            headers = set_bmc_headers(p, "GET", netloc, path)
        else:
            if marker is None:
               #path = path + "/?format=xml&limit=%d" % LIMIT
               options = {'format': 'xml', 'limit': LIMIT}
            else:
               #path = path + "/?format=xml&limit=%d&marker=%s" % (LIMIT, marker)
               options = {'format': 'xml', 'limit': LIMIT, 'marker': marker}

            path = "%s/?%s" % (o.path, urllib.urlencode(options))

        if debug:
            log_msg("opc_getcontainers: Requesting " + netloc + path)

        conn.request("GET", path, None, headers)
        r1 = conn.getresponse()
        if r1.status >= 400:
            log_msg("opc_getcontainers: Error from " + netloc +
                    path + ", status: " + str(r1.status))
            conn.close()
            return 1
        elif debug:
            log_msg("opc_getcontainers: Response from " + netloc +
                    path + ", status: " + str(r1.status))

        if p.cred.isbmcbased():
           resheader = r1.getheaders()
           page = None
           for hdrs in resheader:
               if hdrs[0] == 'opc-next-page':
                   page = hdrs[1]

        bucks = r1.read()
        conn.close()

        if p.cred.isbmcbased():
            bucks_list = json.loads(bucks)
            for buck in bucks_list:
                name = buck.get('name')
                containerlist.append(name)
                if debug:
                    log_msg("opc_getcontainers:    %s" % name)
        else:

            root = ET.fromstring(bucks)

            if root.find("container") is None:
                break

            for f in root.findall("container"):
                name  = f.find("name").text
                count = f.find("count").text
                marker = name
                if ocitype == 'classic':
                    if int(count) == 0:
                        continue
                    else:
                        containerlist.append(name)
                        if debug:
                            log_msg("opc_getcontainers:    %s" %name)
                else:
                    # since swift/bmc does not have count info
                    # for each buckets, we cannot use this to optimize
                    # should remove this part when swift/bmc implement this
                    containerlist.append(name)
                    if debug:
                        log_msg("opc_getcontainers:    %s" %name)

    return 0

#
# cloud_processcontainer - get metadata XMLs in a given container
#
# Parameters
#   - odbs context 
#   - container name that will be scanned
#   - backup piece prefix, used to filter out unwanted backups
#   - include_heartbeat flag, TRUE if heartbeat metadata will included
#   - garbage collection mode flag
#   - database ID, used to filter out unwanted backups
#   - until date string, used to filter backups with specific dates
#   - metadata XML file name list ptr
#   - debug flag
def cloud_processcontainer(p, container, include_heartbeat,
                           garbagecollect, backuppiecelist):

    dbid  = p.dbid

    if not isinstance(backuppiecelist, list):
        log_msg("cloud_processcontainer: Internal Error, NULL or " +
                "NON-LIST backuppiecelist")
        exit(1)

    rc = 0

    del backuppiecelist[:]

    pclist=[]
    rc = opc_processcontainer(p, container, include_heartbeat,
                              garbagecollect, pclist)

    if rc == 1:
        return rc

    # if dbid is given, we construct auxlist that 
    # lists file_chunk/<dbid>/...
    # and use that to find piece handle, 
    # thus filter out pclist for further operation
    auxlist=[]
    if dbid is not None:
        rc = opc_processcontainer_auxlist(p, container, auxlist)
        if rc == 1:
            return rc

    # heartbeat/metadata/2018-05-20/0et3bbqm_1_1/KTVs8w9V0wwD.xml
    if dbid is None:
        backuppiecelist.extend(pclist)
    else:
        for piece in pclist:
            for handle in auxlist:
                m1 = re.search('sbt_catalog/(.*)/metadata.xml', piece)
                m2 = re.search('heartbeat/metadata/.*/(.*)/.*.xml', piece)
                if m1 is not None:
                    tmphdl = m1.group(1)
                    if tmphdl == handle:
                        backuppiecelist.append(piece)
                elif m2 is not None:
                    tmphdl = m2.group(1)
                    if tmphdl == handle:
                        backuppiecelist.append(piece)

    return rc


#
# opc_processcontainer_auxlist - get list of backuppiece handles in 
#                                a given container
#                                with the specific DBID
#
# Parameters
#   - odbs context 
#   - container name that will be scanned
#   - database ID, used to filter backups associated with this DBID
#   - auxiliary list, that stores final list of bkps handle names with specified DBID
def opc_processcontainer_auxlist(p, container, auxlist):

    for ii in range(0, RETRY):
        del auxlist[:]
        rc = opc_processcontainer_auxlist_int(p, container, auxlist)
        if rc == 0:
            break
        elif ii < (RETRY - 1):
            log_msg("opc_processcontainer_auxlist: " +
                    "Failed to get auxlist in %s, RETRYING..."
                    % container)

    return rc

#
# opc_processcontainer_auxlist_int - get list of backuppiece handles in a given container
#                                    with the specific DBID
#
# Parameters
#   - odbs context 
#   - container name that will be scanned
#   - database ID, used to filter backups associated with this DBID
#   - auxiliary list, that stores final list of bkps handle names with specified DBID
def opc_processcontainer_auxlist_int(p, container, auxlist):

    headers = p.headers
    host    = p.host
    proxyhost = p.proxyhost
    proxyport = p.proxyport
    bpprefix  = p.bpprefix
    dbid      = p.dbid
    untildate = p.untildate
    debug     = p.debug

    if not isinstance(auxlist, list):
        log_msg("opc_processcontainer_auxlist_int: "+
                "Internal Error, NULL or NON-LIST auxlist")
        exit(1)

    if dbid is None:
        log_msg("opc_processcontainer_auxlist_int: Internal Error, NULL dbid")
        exit(1)

    o = urlparse.urlparse(host)
    marker = None
    start  = None

    while True:
        netloc = o.netloc
        path = o.path

        if proxyhost is None:
            conn = httplib.HTTPSConnection(netloc, timeout=LIST_TIMEOUT)
        else:
            conn = httplib.HTTPSConnection(proxyhost, proxyport,
                                           timeout=LIST_TIMEOUT)
            tunnel_header = {}
            #tunnel_header['Proxy-Connection'] = 'Keep-Alive'
            conn.set_tunnel(netloc, 443, tunnel_header)


        if p.cred.isbmcbased():
            if start is None:
                #path = ("/n/%s/b/%s/o?limit=%d&prefix=%s" %
                #        (p.namespace, container, BMC_LIMIT,
                #         "file_chunk/" + str(dbid))
                options = {'limit': BMC_LIMIT,
                           'prefix': "file_chunk/%d" % dbid,
                           'fields': 'timeCreated'}
            else:
                #path = ("/n/%s/b/%s/o?limit=%d&prefix=%s%d&start=%s" %
                #        (p.namespace, container, BMC_LIMIT, "file_chunk/", dbid,start))
                options = {'limit': BMC_LIMIT,
                           'prefix': "file_chunk/%d" % dbid,
                           'fields': 'timeCreated', 'start': start}

            path = "/n/%s/b/%s/o?%s" % (p.namespace, container,
                                        urllib.urlencode(options))

            # BMC headers needs to be specified for each REQUEST separately
            headers = set_bmc_headers(p, "GET", netloc, path)
        else:
            if marker is None:
                #path = (path + "/" + container + "/?format=xml&limit=" +
                #        str(LIMIT) +
                #        "&prefix=file_chunk/" + str(dbid))
                options = {'format': 'xml', 'limit': LIMIT,
                           'prefix': "file_chunk/%d" % dbid}
            else:
                path = (path + "/" + container + "/?format=xml&limit=" +
                        str(LIMIT) +
                        "&prefix=file_chunk/" + str(dbid) + "&marker=" + marker)
                options = {'format': 'xml', 'limit': LIMIT,
                           'prefix': "file_chunk/%d" % dbid,
                           'marker': marker}

            path = "%s/%s/?%s" % (o.path, container, urllib.urlencode(options))

        if debug:
            log_msg("opc_processcontainer_auxlist_int: Requesting " + netloc + path)

        conn.request("GET", path, None, headers)
        r1 = conn.getresponse()
        if r1.status >= 400:
            log_msg("opc_processcontainer_auxlist_int: Error from " +
                    netloc + path + ", status: " + str(r1.status))
            conn.close()
            return 1
        elif debug:
            log_msg("opc_processcontainer_auxlist_int: Response from " +
                    netloc + path + ", status: " + str(r1.status))

        objects = r1.read()
        conn.close()

        if p.cred.isbmcbased():
            output = json.loads(objects)
            start = output.get("nextStartWith")
            objects_list = output.get("objects")

            if debug:
                log_msg("opc_processcontainer_auxlist_int: nextSTART=%s" % start)

            if len(objects_list) == 0:
                break

            for obj in objects_list:
                name = obj.get("name")
                last_mod = obj.get("timeCreated")

                regformat = "file_chunk/%d/.*/backuppiece/.*/(.*)/.*/metadata.xml" % dbid

                if not re.match(regformat, name):
                    continue
                else:
                    m = re.search(regformat, name)
                    handle = m.group(1)

                if bpprefix is not None:
                    if not re.match('^' + bpprefix, handle):
                        continue

                if not piece_datecheck(last_mod, untildate, name, debug):
                   continue

                auxlist.append(handle)

                if debug:
                    log_msg("opc_processcontainer_auxlist_int:    %s" % name)

            if start is None:
                break

        else:
            root = ET.fromstring(objects)

            if root.find("object") is None:
                break

            # name =~ file_chunk/851587338/AIME1/backuppiece/2018-05-13/odbsrmt01/ZyH3tH16jobK/metadata.xml

            for f in root.findall("object"):
                name = f.find("name").text
                last_mod = f.find("last_modified").text
                marker = name

                regformat = "file_chunk/%d/.*/backuppiece/.*/(.*)/.*/metadata.xml" % dbid

                if not re.match(regformat, name):
                    continue
                else:
                    m = re.search(regformat, name)
                    handle = m.group(1)

                if bpprefix is not None:
                    if not re.match('^' + bpprefix, handle):
                        continue

                if not piece_datecheck(last_mod, untildate, name, debug):
                    continue

                auxlist.append(handle)

                if debug:
                    log_msg("opc_processcontainer_auxlist_int:    %s" % name)

    return 0

#
# opc_processcontainer - get metadata XMLs in a given container
#
# Parameters
#   - odbs context 
#   - container name that will be scanned
#   - include_heartbeat flag, TRUE if heartbeat metadata will included
#   - garbage collection mode flag
#   - metadata XML file name list ptr
def opc_processcontainer(p, container, include_heartbeat,
                         garbagecollect, pclist):

    list1 = []
    list2 = []

    bpprefix = p.bpprefix

    if include_heartbeat:
        prefix_option = "heartbeat/metadata"
        for ii in range(0, RETRY):
            del list1[:]
            rc = opc_getxmlobjects(p, container, prefix_option,
                                   include_heartbeat, list1)
            if rc == 0:
                break
            elif ii < (RETRY -1):
                log_msg("opc_processcontainer: Failed to get " +
                        "heartbeat metadata list in %s, RETRYING..."
                        % container)

        if rc == 1:
            return rc

    # get sbt_catalog xmls if not garbage collect
    if not garbagecollect:
        if bpprefix is not None:
            prefix_option = "sbt_catalog/"+bpprefix
        else:
            prefix_option = "sbt_catalog/"
        for ii in range(0, RETRY):
            del list2[:]
            rc = opc_getxmlobjects(p, container, prefix_option,
                                   include_heartbeat, list2)
            if rc == 0:
               break
            elif ii < (RETRY -1):
               log_msg("opc_processcontainer: Failed to get sbt_catalog " +
                       "metadata list in %s, RETRYING..." % container)

        if rc == 1:
            return rc

    pclist.extend(list1)
    pclist.extend(list2)

    return rc

#
# opc_getxmlobjects - get a list of qualifying XML files
#
# Parameters
#   - request header hash
#   - host name
#   - container name that will be scanned
#   - prefix_option, ?prefix option in GET request, used to reduce unnecessary HTTPS response
#   - backup piece name prefix, used to filter out unwanted backups
#   - include_heartbeat flag, TRUE if heartbeat metadata will included
#   - until date string, used to filter backups with specific dates
#   - metadata XML file name list ptr
#   - debug flag
def opc_getxmlobjects(p, container, prefix_option,
                      include_heartbeat, pclist):

    headers   = p.headers
    host      = p.host
    proxyhost = p.proxyhost
    proxyport = p.proxyport
    bpprefix  = p.bpprefix
    untildate = p.untildate
    debug     = p.debug

    if not isinstance(pclist, list):
        log_msg("opc_getxmlobjects: Internal Error, NULL or " +
                "NON-LIST pclist")
        exit(1)

    o = urlparse.urlparse(host)
    marker = None
    start  = None

    while True:
        netloc = o.netloc
        path = o.path

        if proxyhost is None:
            conn = httplib.HTTPSConnection(netloc, timeout=LIST_TIMEOUT)
        else:
            conn = httplib.HTTPSConnection(proxyhost, proxyport,
                                           timeout=LIST_TIMEOUT)
            tunnel_header = {}
            #tunnel_header['Proxy-Connection'] = 'Keep-Alive'
            conn.set_tunnel(netloc, 443, tunnel_header)

        if p.cred.isbmcbased():
            if start is None:
                if prefix_option is None:
                    #path = "/n/%s/b/%s/o?limit=%d" %
                    # (p.namespace, container, BMC_LIMIT)
                    options = {'limit': BMC_LIMIT,
                               'fields': 'timeCreated'}

                else:
                    #path = ("/n/%s/b/%s/o?limit=%d&prefix=%s" %
                    #        (p.namespace, container, BMC_LIMIT, prefix_option))
                    options = {'limit': BMC_LIMIT,
                               'prefix': prefix_option,
                               'fields': 'timeCreated'}
            else:
                if prefix_option is None:
                    #path = ("/n/%s/b/%s/o?limit=%d&start=%s" %
                    #        (p.namespace, container, BMC_LIMIT, start))
                    options = {'limit': BMC_LIMIT,
                               'start': start,
                               'fields': 'timeCreated'}
                else:
                    #path = ("/n/%s/b/%s/o?limit=%d&prefix=%s&start=%s" %
                    #        (p.namespace, container, BMC_LIMIT, prefix_option, start))
                    options = {'limit': BMC_LIMIT,
                               'prefix': prefix_option,
                               'fields': 'timeCreated',
                               'start': start}

            path = "/n/%s/b/%s/o?%s" % (p.namespace, container, urllib.urlencode(options))

            # BMC headers needs to be specified for each REQUEST separately
            headers = set_bmc_headers(p, "GET", netloc, path)
        else:
            if marker is None:
                if prefix_option is None:
                    #path = (path + "/" + container + "/?format=xml&limit=" +
                    #        str(LIMIT))
                    options = {'format': 'xml',
                               'limit': LIMIT}
                else:
                    #path = (path + "/" + container + "/?format=xml&limit=" +
                    #        str(LIMIT) +
                    #        "&prefix=" + prefix_option)
                    options = {'format': 'xml',
                               'limit': LIMIT,
                               'prefix': prefix_option}
            else:
                if prefix_option is None:
                    #path = (path + "/" + container + "/?format=xml&limit=" +
                    #        str(LIMIT) + "&marker=" + marker)
                    options = {'format': 'xml',
                               'limit': LIMIT,
                               'marker': marker}
                else:
                    #path = (path + "/" + container + "/?format=xml&limit=" +
                    #        str(LIMIT) +
                    #        "&prefix=" + prefix_option + "&marker=" + marker)
                    options = {'format': 'xml',
                               'limit': LIMIT,
                               'prefix': prefix_option,
                               'marker': marker}

            path = "%s/%s/?%s" % (o.path, container,
                                  urllib.urlencode(options))

        if debug:
            log_msg("opc_getxmlobjects: Requesting " + netloc + path)

        conn.request("GET", path, None, headers)
        r1 = conn.getresponse()
        if r1.status >= 400:
            log_msg("opc_getxmlobjects: Error from " + netloc + path +
                    ", status: " + str(r1.status))
            conn.close()
            return 1
        elif debug:
            log_msg("opc_getxmlobjects: Response from " + netloc + path +
                    ", status: " + str(r1.status))

        objects = r1.read()
        conn.close()

        if p.cred.isbmcbased():
            output = json.loads(objects)
            start = output.get("nextStartWith")
            objects_list = output.get("objects")

            if debug:
                log_msg("opc_getxmlobjects: nextSTART=%s" % start)

            if len(objects_list) == 0:
                break

            for obj in objects_list:
                name = obj.get("name")
                last_mod = obj.get("timeCreated")

                if not (re.match('sbt_catalog/.*/metadata.xml', name) or
                            re.match('heartbeat/metadata/.*.xml', name)):
                    continue

                if bpprefix is not None:
                    if not (re.match('sbt_catalog/' + bpprefix + '.*/metadata.xml', name) or
                            re.match('heartbeat/metadata/.*/' + bpprefix + '.*/.*.xml', name)):
                        continue

                if not piece_datecheck(last_mod, untildate, name, debug):
                    continue

                pclist.append(name)

                if debug:
                    log_msg("opc_getxmlobjects:    %s" % name)

            if start is None:
                break

        else:
            root = ET.fromstring(objects)

            if root.find("object") is None:
                break

            for f in root.findall("object"):
                name = f.find("name").text
                last_mod = f.find("last_modified").text
                marker = name

                if not (re.match('sbt_catalog/.*/metadata.xml', name) or
                        re.match('heartbeat/metadata/.*.xml', name)):
                    continue

                if bpprefix is not None:
                    if not (re.match('sbt_catalog/' + bpprefix + '.*/metadata.xml', name) or
                            re.match('heartbeat/metadata/.*/' + bpprefix + '.*/.*.xml', name)):
                        continue

                if not piece_datecheck(last_mod, untildate, name, debug):
                    continue

                pclist.append(name)

                if debug:
                    log_msg("opc_getxmlobjects:    %s" % name)

    return 0

#
# piece_datecheck - function to check if last_modified date is eligible for
#                   further process
#
# Parameters
#   - last_modified date of backup piece
#   - until date string, used to filter backups with specific dates
#   - path name of XML file
#   - debug flag
def piece_datecheck(last_mod, untildate, name, debug):

    if last_mod is None:
        log_msg("piece_datecheck: Missing Last-modified " +
                "timestamp for %s" % name)
        return False
    elif re.match('(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}).*', last_mod):
        m = re.search('(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}).*', last_mod)
        tmpdate = m.group(1) + ' ' + m.group(2)
        lastmod_date = datetime.datetime.strptime(tmpdate, "%Y-%m-%d %H:%M")
    elif re.match('(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}).*', last_mod):
        m = re.search('(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}).*', last_mod)
        tmpdate = m.group(1) + ' ' + m.group(2)
        lastmod_date = datetime.datetime.strptime(tmpdate, "%Y-%m-%d %H:%M")
    else:
        return False

    # return False is until date is less then file date
    if untildate is not None:
        until_date = datetime.datetime.strptime(untildate, "%Y-%m-%d")
        if until_date.date() <= lastmod_date.date():
            return False

    # if heartbeat is within 24 hours, we regard it as ongoing backup
    # and return False
    if re.match('heartbeat/metadata.*', name):
        cur_date = datetime.datetime.utcnow()
        if (cur_date - lastmod_date) < datetime.timedelta(hours=24):
            if debug:
                log_msg("piece_datecheck: %s is within 24 hours, " % name +
                        "may be on going backup piece, SKIP IT")
            return False

    return True

#
# cloud_slave_processors - slave threads, each thread conusmes ctx.queue, which
#                          downloads metadata.xml, report them to output file,
#                          or finds all associated file_chunks and form a delete list
#                          and perform bulk-delete
#
# Parameters
#   - name of the thread
#   - thread context ptr
#   - file base name for contructing output file(for delete/garbage-collect mode
#     since multiple files are to be created)
#   - request header hash
#   - host name
#   - mode of the script, REPORT/RMAN-LISTFILE/DELETE/GARBAGE-COLLECTION
#   - output format, TEXT/XML/JSON
#   - debug flag
def cloud_slave_processors(threadname, ctx, p):

    queue = ctx.queue
    totalsize = 0

    if p.forcename is not None:
        fbasename = get_log_file_name(p.dir, p.forcename, p.debug)
    elif p.base is not None:
        fbasename = (get_log_file_name(p.dir, p.base, p.debug) +
                     str(os.getpid()))

    headers = p.headers
    host    = p.host
    mode    = p.mode
    format  = p.format
    debug   = p.debug
    skip_check_status = p.skip_check_status

    report         = True if mode == 'report' else False
    rmanlistfile   = True if mode == 'rman-listfile' else False
    garbagecollect = True if mode == 'garbage-collection' else False
    delete         = True if mode == 'delete' else False
    recall = True if mode == 'recall' else False

    txttemplate_report = "%-30s\n%-25s%-15s%-12s%-18s%-28s%-28s%-13s%-13s%-12s\n"

    xmltemplate_report = \
'''   <File>
      <Container>%s</Container>
      <Dbname>%s</Dbname>
      <Dbid>%s</Dbid>
      <Filename>%s</Filename>
      <Filesize>%s</Filesize>
      <LastModified>%s</LastModified>
      <BackupType>%s</BackupType>
      <Incremental>%s</Incremental>
      <Compressed>%s</Compressed>
      <Encrypted>%s</Encrypted>
   </File>
'''

    xmltemplate_rmanlist = \
'''   <File>
      <Filename>%s</Filename>
      <SetStamp>%s</SetStamp>
      <IsSpfile>%s</IsSpfile>
      <IsControlFile>%s</IsControlFile>  
      <PieceNo>%s</PieceNo>
      <Dbname>%s</Dbname>
      <Dbid>%s</Dbid>          
   </File>
'''
    jsontemplate_report = \
'''   {
      "Container": "%s",
      "Dbname": "%s",
      "Dbid": %s,
      "Filename": "%s",
      "Filesize": %s,
      "LastModified": "%s",
      "BackupType": "%s",
      "Incremental": "%s",
      "Compressed": "%s",
      "Encrypted": "%s"     
   }
'''

    textformat = False
    jsonformat = False
    xmlformat  = False
    if (format == "text") or (format is None):
        textformat = True
    elif format == "xml":
        xmlformat = True
    elif format == "json":
        jsonformat = True
    else:
        textformat = True

    fh = None
    if delete or garbagecollect:
        # write file and chunklist into deletion file
        if p.forcename is None:
            del_filename = fbasename + '_' + threadname + '.lst'
        else:
            m = re.search('(.*).(.*)', fbasename)
            if m is not None:
                fbase1 = m.group(1)
                fext2 = m.group(2)
                del_filename = fbase1 + '_' + threadname + '.' + fext2
            else:
                del_filename = fbasename + '_' + threadname

        fh = open(del_filename, 'w')
        if debug:
            with ctx.loglock:
                log_msg("cloud_slave_processors: " +
                        "opened file %s for DELETE in thread %s" %
                        (del_filename, threadname))

        with ctx.loglock:
            log_msg("cloud_slave_processors: Thread %s starting" %
                    threadname +
                    " download metadata XML files and fetch file chunks of backup pieces...")
    elif report or rmanlistfile or recall:
        fh = ctx.filehandle
        if recall:
            with ctx.loglock:
                log_msg("cloud_slave_processors: Thread %s starting" %
                        threadname +
                        " to fetch file chunks and send RECALL requests...")
        elif report or rmanlistfile:
            with ctx.loglock:
                log_msg("cloud_slave_processors: Thread %s starting" %
                        threadname +
                        " to download metadata XML files...")

    chunklist = []
    joblist = []
    alljoblist = []

    while True:
        try:
            # non-blocking get call, will raise EMPTY exception if queue is
            # empty
            file_elem = queue.get(False)
            file = file_elem.piecename
            con  = file_elem.container

            pc_metadata_ptr = [0]
            rc = cloud_downloadXMLs(ctx, p, file, con, pc_metadata_ptr)
            if rc == 1:
                with ctx.loglock:
                    log_msg("cloud_slave_processors: " +
                            "Thread %s failed to download " % threadname +
                            "%s in container %s, try next..."
                            % (file, con))
                continue

            pc_metadata = pc_metadata_ptr[0]

            # a date check is done in cloud_downloadXMLS
            # if date check is not passed
            # (ongoing-backup/greater than untidate etc..)
            # pc_metadata is None, then skip further processing
            # and go to next obj
            if pc_metadata is None:
                continue

        except Queue.Empty:
            if debug:
                with ctx.loglock:
                    log_msg("cloud_slave_processors: Queue empty, " +
                            "%s is done reading backuppiece metadata"
                            % threadname)
            break

        if debug:
            with ctx.loglock:
                log_msg("cloud_slave_processors: " +
                        "Thread %s has downloaded %s" % (threadname, file))

        if delete or garbagecollect:
            # we will list files with chunk_prefix
            # and put them into a deletion file
            del chunklist[:]

            if pc_metadata.chunkprefix is not None:
                rc = cloud_listfilechunk(ctx, p, con, pc_metadata.chunkprefix,
                                         chunklist)
                if rc == 1:
                    with ctx.loglock:
                        log_msg("cloud_slave_processors: Thread %s "
                                % threadname +
                                "failed to get file chunk list for %s" % file)
                    del chunklist[:]
            else:
                del chunklist[:]

            # write file and chunklist into deletion file
            fh.write(con + '/' + file + "\n")
            for chunkitem in chunklist:
                fh.write(con + '/' + chunkitem + "\n")

        elif report or rmanlistfile or recall:
            # we will write metadata into output file now,
            # the shared output file is already opened
            # with fh = ctx.filehandle pointer
            if report:
                totalsize = totalsize + int(pc_metadata.filesize)
                if textformat:
                    with ctx.fhlock:
                        fh.write(txttemplate_report % (pc_metadata.filename, con,
                                                       pc_metadata.dbname,
                                                       pc_metadata.dbid,
                                                       pc_metadata.filesize,
                                                       pc_metadata.lastmodified,
                                                       pc_metadata.backuptype,
                                                       pc_metadata.incremental,
                                                       pc_metadata.compressed,
                                                       pc_metadata.encrypted))

                elif xmlformat:
                    with ctx.fhlock:
                        fh.write(xmltemplate_report % (con, pc_metadata.dbname,
                                                       pc_metadata.dbid,
                                                       pc_metadata.filename,
                                                       pc_metadata.filesize,
                                                       pc_metadata.lastmodified,
                                                       pc_metadata.backuptype,
                                                       pc_metadata.incremental,
                                                       pc_metadata.compressed,
                                                       pc_metadata.encrypted))
                elif jsonformat:
                    with ctx.fhlock:
                        if ctx.json_firstentry_flag is True:
                            ctx.json_firstentry_flag = False
                        else:
                            fh.write('   ,\n')
                        fh.write(jsontemplate_report % (con, pc_metadata.dbname,
                                                       pc_metadata.dbid,
                                                       pc_metadata.filename,
                                                       pc_metadata.filesize,
                                                       pc_metadata.lastmodified,
                                                       pc_metadata.backuptype,
                                                       pc_metadata.incremental,
                                                       pc_metadata.compressed,
                                                       pc_metadata.encrypted))

            elif rmanlistfile or recall:
                isspfile = 'NO'
                iscontrolfile = 'NO'

                if re.match('.*SPFILE.*', pc_metadata.backuptype,
                            flags=re.IGNORECASE):
                    isspfile = 'YES'

                if re.match('.*ControlFile.*', pc_metadata.backuptype,
                            flags=re.IGNORECASE):
                    iscontrolfile = 'YES'

                with ctx.fhlock:
                    fh.write(xmltemplate_rmanlist % (pc_metadata.filename,
                                                     pc_metadata.setstamp,
                                                     isspfile, iscontrolfile,
                                                     pc_metadata.pieceno,
                                                     pc_metadata.dbname,
                                                     pc_metadata.dbid))

                # This is the real RECALL request for all file chunks associated with filename
                if recall:
                    # we will list files with chunk_prefix
                    # and put them into a deletion file

                    del chunklist[:]
                    if pc_metadata.chunkprefix is not None:
                        rc = cloud_listfilechunk(ctx, p, con, pc_metadata.chunkprefix,
                                                 chunklist)
                        if rc == 1:
                            with ctx.loglock:
                                log_msg("cloud_slave_processors: Thread %s "
                                        % threadname +
                                        "failed to get file chunk list for %s" % file)
                            del chunklist[:]
                    else:
                        del chunklist[:]

                    del joblist[:]

                    rc = archive_recall_request(ctx, p, con, chunklist, joblist)

                    if rc == 1:
                        with ctx.loglock:
                            log_msg("cloud_slave_processors: Thread %s failed "
                                    % threadname +
                                    "to RECALL %s chunks in %s"
                                    % (pc_metadata.filename, con))
                            del joblist[:]
                    else:
                        if debug:
                            with ctx.loglock:
                                log_msg("cloud_slave_processors: Thread %s successfully"
                                        % threadname +
                                        " RECALLED %s chunks in %s"
                                        % (pc_metadata.filename, con))

                    alljoblist.extend(joblist)


    # report or rman-listfile mode share the same
    # output file for multi-thread, so will not close it
    # when a single thread is done
    if delete or garbagecollect:
       if fh is not None:
          fh.close()

    # send DELETE request after delete file is done
    if delete or garbagecollect:
       with ctx.loglock:
          log_msg("cloud_slave_processors: Thread %s starting"
                   % threadname +
                  " to send DELETE requests to cloud...")

       rc = cloud_delete_request(ctx, p, del_filename)
       if rc == 1:
          with ctx.loglock:
             log_msg("cloud_slave_processors: Thread %s failed "
                      % threadname +
                     "to DELETE files in %s" % del_filename)
       else:
          with ctx.loglock:
             log_msg("cloud_slave_processors: Thread %s successfully"
                      % threadname +
                     " DELETED files in %s" % del_filename)
    elif report or rmanlistfile:
        if report:
           # put totalsize into calsize_queue
           ctx.calsize_queue.put(totalsize)
        with ctx.loglock:
            log_msg("cloud_slave_processors: Thread %s successfully done"
                     % threadname)

    # If recall and not skip_check_status, we loop through joblist
    # to check each request's status until everything is ready for retieval
    # in archive storage
    if recall and not skip_check_status:

        with ctx.loglock:
            log_msg("cloud_slave_processors: Thread %s starting"
                     % threadname +
                    " to check RECALL STATUS of file chunks...")

        if len(alljoblist) == 0:
            with ctx.loglock:
                log_msg("cloud_slave_processors: Thread %s: "
                         % threadname +
                        "no chunk to check status")
            return

        status_ptr = [0]
        count = 1
        check_finished = False
        while count <= MAX_CHECK_ROUND:
            count += 1
            alldone = True
            lowest_percentage = 100

            for jobelem in alljoblist:

                jobid = jobelem.jobid
                con   = jobelem.container
                chunk = jobelem.chunkname

                rc = check_job_status(ctx, p, con, chunk, jobid, status_ptr)

                if rc == 1:
                    with ctx.loglock:
                        log_msg("cloud_slave_processors: Thread %s failed "
                                 % threadname +
                                "to CHECK STATUS of chunk %s with jobid %s"
                                 % (chunk, jobid))
                    alldone = False
                    break
                else:
                    if debug:
                        with ctx.loglock:
                            log_msg("cloud_slave_processors: Thread %s successfully"
                                     % threadname +
                                    " CHECKED STATUS of chunk %s with jobid %s"
                                     % (chunk, jobid))

                status = status_ptr[0]
                progress = status.progress
                completed = status.completed
                completed_percentage = status.completed_percentage

                if not completed:
                    alldone = False
                    if completed_percentage < lowest_percentage:
                        lowest_percentage = completed_percentage

            if alldone:
                check_finished = True
                break
            else:
                with ctx.loglock:
                    if rc == 1:
                        log_msg("cloud_slave_processors: Error in checking status request, " +
                                "thread %s pausing %d seconds for the next round of checks..."
                                 % (threadname, CHECK_STATUS_PAUSE))
                    else:
                        log_msg("cloud_slave_processors: Lowest completed percentage " +
                                "among all chunks is %d%%, " % lowest_percentage +
                                "thread %s pausing %d seconds for the next round of checks..."
                                 % (threadname, CHECK_STATUS_PAUSE))

                time.sleep(CHECK_STATUS_PAUSE)

        if count > MAX_CHECK_ROUND:
            with ctx.loglock:
                log_msg("cloud_slave_processors: " +
                        "Round of checks exceeding max value in thread %s, "
                        % threadname +
                        "either files are not ready yet or fatal error occured")
        elif check_finished:
            with ctx.loglock:
                log_msg("cloud_slave_processors: " +
                        "Successfully checked all RECALL STATUS in thread %s, "
                        % threadname +
                        "files are ready to be retrieved")
    return

#
# check_job_status - send GET request to check recall job status
#
#
# Parameters
#   - thread context ptr
#   - odbs context ptr
#   - container name
#   - recall job id
def check_job_status(ctx, p, con, chunk, jobid, status_ptr):

    if not isinstance(status_ptr, list):
        with ctx.loglock:
            log_msg("check_job_status: Internal Error, NULL or " +
                    "NON-LIST status_ptr")
            exit(1)

    for ii in range(0, RETRY):
        rc = check_job_status_request(ctx, p, con, chunk, jobid, status_ptr)
        if rc == 0:
            break
        elif ii < (RETRY - 1):
            with ctx.loglock:
                log_msg("check_job_status: Failed to send GET " +
                        "request to CHECK STATUS of job %s, RETRYING..." % jobid)

    return rc

#
# check_job_status_request - send GET request to check recall job status
#
#
# Parameters
#   - thread context ptr
#   - odbs context ptr
#   - container name
#   - recall job id
def check_job_status_request(ctx, p, con, chunk, jobid, status_ptr):

    headers = p.headers
    host = p.host
    proxyhost = p.proxyhost
    proxyport = p.proxyport
    debug = p.debug

    o = urlparse.urlparse(host)

    netloc = o.netloc
    path = o.path

    # archive storage check status path requires v0
    m = re.search('/(v\d)/.*', path)
    if m is None:
        with ctx.loglock:
            log_msg("check_job_status_request: " +
                    "Internal error, incorrect path format.")
        return 1

    path = re.sub('^/v1/', '/v0/', path)

    if proxyhost is None:
        conn = httplib.HTTPSConnection(netloc, timeout=RECALL_TIMEOUT)
    else:
        conn = httplib.HTTPSConnection(proxyhost, proxyport,
                                       timeout=RECALL_TIMEOUT)
        tunnel_header = {}
        # tunnel_header['Proxy-Connection'] = 'Keep-Alive'
        conn.set_tunnel(netloc, 443, tunnel_header)

    # if debug:
    #    conn.set_debuglevel(2)

    options = {'jobId': jobid}
    #path = '%s/%s?jobs&jobId=%s' % (path, con, jobid)
    path = "%s/%s?jobs&%s" % (path, con, urllib.urlencode(options))

    if debug:
        with ctx.loglock:
            log_msg("check_job_status_request: Requesting " + netloc + path)

    conn.request("GET", path, None, headers)
    r1 = conn.getresponse()
    if r1.status >= 400:
        with ctx.loglock:
            log_msg("check_job_status_request: Error from " + netloc +
                    path + ", status: " + str(r1.status))
        conn.close()
        return 1
    elif debug:
        with ctx.loglock:
            log_msg("check_job_status_request: Response from " +
                    netloc + path + ", status: " + str(r1.status))

    output = r1.read()
    conn.close()

    result = json.loads(output)
    progress = result.get("progress")
    completed = result.get("completed")
    completed_percentage = result.get("completedPercentage")

    status = JobStatus(con, chunk, jobid, progress,
                       completed, completed_percentage)

    status_ptr[0] = status

    return 0


#
# archive_recall_request - send POST request to recall file chunks in chunklist
#
#
# Parameters
#   - thread context ptr
#   - odbs context ptr
#   - container name
#   - list of file chunks
#   - list of job ids for each file chunk recall request
def archive_recall_request(ctx, p, con, chunklist, joblist):

    if not isinstance(joblist, list):
        with ctx.loglock:
            log_msg("archive_recall_request: Internal Error, NULL or " +
                    "NON-LIST joblist")
            exit(1)

    del joblist[:]
    jobid_ptr = [0]

    for chunk in chunklist:

        if re.match('.*.xml$', chunk):
            continue

        for ii in range(0, RETRY):
            rc = archive_recall_request_single(ctx, p, con, chunk, jobid_ptr)
            if rc == 0:
                break
            elif ii < (RETRY - 1):
                with ctx.loglock:
                    log_msg("archive_recall_request: Failed to send POST " +
                            "request to RECALL %s, RETRYING..." % chunk)
        if rc == 1:
            return 1

        job_elem = Jobelem(con, chunk, jobid_ptr[0])
        joblist.append(job_elem)

    return 0


#
# archive_recall_request_single - send POST request to recall a single file chunk
#
#
# Parameters
#   - thread context ptr
#   - odbs context ptr
#   - container name
#   - file chunk name
#   - jobid pointer
def archive_recall_request_single(ctx, p, con, chunk, jobid_ptr):

    headers = p.headers
    host = p.host
    proxyhost = p.proxyhost
    proxyport = p.proxyport
    debug = p.debug

    o = urlparse.urlparse(host)

    netloc = o.netloc
    path = o.path

    # archive storage recall path requires v0
    m = re.search('/(v\d)/.*', path)
    if m is None:
        with ctx.loglock:
            log_msg("archive_recall_request_single: " +
                    "Internal error, incorrect path format.")
        return 1

    path = re.sub('^/v1/','/v0/', path)

    if proxyhost is None:
        conn = httplib.HTTPSConnection(netloc, timeout=RECALL_TIMEOUT)
    else:
        conn = httplib.HTTPSConnection(proxyhost, proxyport,
                                       timeout=RECALL_TIMEOUT)
        tunnel_header = {}
        # tunnel_header['Proxy-Connection'] = 'Keep-Alive'
        conn.set_tunnel(netloc, 443, tunnel_header)

    #if debug:
    #    conn.set_debuglevel(2)

    path = '%s/%s/%s?restore' % (path, con, chunk)

    if debug:
        with ctx.loglock:
            log_msg("archive_recall_request_single: Requesting " + netloc + path)

    conn.request("POST", path, None, headers)
    r1 = conn.getresponse()
    if r1.status >= 400:
        with ctx.loglock:
            log_msg("archive_recall_request_single: Error from " + netloc +
                    path + ", status: " + str(r1.status))
        conn.close()
        return 1
    elif debug:
        with ctx.loglock:
            log_msg("archive_recall_request_single: Response from " +
                    netloc + path + ", status: " + str(r1.status))

    resheader = r1.getheaders()

    jobid = None
    for hdrs in resheader:
        if hdrs[0] == 'x-archive-restore-jobid':
            jobid = hdrs[1]

    if jobid is None:
        log_msg("archive_recall_request_single: Unable to identify JobId of request")
        conn.close
        return 1

    conn.close()

    jobid_ptr[0] = jobid

    return 0

#
# cloud_delete_request - send bulk-delete request with delete-file name
#
#
# Parameters
#   - thread context ptr
#   - odbs context ptr
#   - delete-file name
def cloud_delete_request(ctx, p, del_filename):

    for ii in range(0, RETRY):
        if p.cred.isbmcbased():
            rc = bmc_delete_request(ctx, p, del_filename)
        else:
            rc = opc_delete_request(ctx, p, del_filename)
        if rc == 0:
            break
        elif ii < (RETRY - 1):
            with ctx.loglock:
                log_msg("cloud_delete_request: Failed to send DELETE " +
                        "request with %s, RETRYING..." % del_filename)

    return rc

#
# opc_delete_request - send bulk-delete request with delete-file name
#
#
# Parameters
#   - thread context ptr
#   - odbs context ptr
#   - delete-file name
def opc_delete_request(ctx, p, del_filename):
    
    headers = p.headers
    host    = p.host
    proxyhost = p.proxyhost
    proxyport = p.proxyport
    debug     = p.debug

    del_headers={}
    del_headers["Authorization"]=headers["Authorization"]
    del_headers["Content-type"]="text/plain"
    del_headers["Accept"] = "*/*"

    line_cnt = 0
    del_body = ''
    del_body_list=[]
    # because delete request accept no more than 10000 lines per REQUEST
    # divide objects into sub sections and store in del_body_list[]
    # odbsrmt splits into DEL_LIMIT objects with a value less than 10000
    with open(del_filename, "r") as del_fh:
        while True:
            if line_cnt == DEL_LIMIT:
                del_body_list.append(del_body)
                line_cnt = 0
                del_body = ''
            else:
                line = del_fh.readline()
                line_cnt = line_cnt + 1
                if line is None or line == '':
                    if del_body != '':
                        del_body_list.append(del_body)
                    break
                del_body = del_body + line

    o = urlparse.urlparse(host)

    for data in del_body_list:
        netloc = o.netloc
        path = o.path

        if proxyhost is None:
            conn = httplib.HTTPSConnection(netloc, timeout=DEL_TIMEOUT)
        else:
            conn = httplib.HTTPSConnection(proxyhost, proxyport,
                                           timeout=DEL_TIMEOUT)
            tunnel_header = {}
            #tunnel_header['Proxy-Connection'] = 'Keep-Alive'
            conn.set_tunnel(netloc, 443, tunnel_header)

        #if debug:
         #  conn.set_debuglevel(2)

        path = path + "?bulk-delete"

        if debug:
            with ctx.loglock:
                log_msg("opc_delete_request: Requesting " + netloc + path)

        conn.request("DELETE", path, data, del_headers)
        r1 = conn.getresponse()
        if r1.status >= 400:
            with ctx.loglock:
               log_msg("opc_delete_request: Error from " + netloc +
                       path + ", status: " + str(r1.status))
            conn.close()
            return 1
        elif debug:
            with ctx.loglock:
                log_msg("opc_delete_request: Response from " +
                        netloc + path + ", status: " + str(r1.status))

        with ctx.loglock:
            log_msg(r1.read())
        conn.close()

    return 0

#
# bmc_delete_request - send delete request for BMC, since
#                      BMC does not support bulkdelete now
#
#
# Parameters
#   - thread context ptr
#   - odbs context ptr
#   - delete-file name
def bmc_delete_request(ctx, p, del_filename):
    headers = p.headers
    host = p.host
    proxyhost = p.proxyhost
    proxyport = p.proxyport
    debug = p.debug

    del_list = []

    with open(del_filename, "r") as del_fh:
        while True:
            line = del_fh.readline().strip()
            if line is None or line == '':
                break
            else:
                del_list.append(line)

    o = urlparse.urlparse(host)

    for object in del_list:

        # non-greedy match, otherwise container will have filename protion
        m = re.search("(.*?)/(.*)", object)
        if m is not None:
            container = m.group(1)
            filename  = m.group(2)
        else:
            continue

        netloc = o.netloc
        #path = o.path

        if proxyhost is None:
            conn = httplib.HTTPSConnection(netloc, timeout=BMC_DEL_TIMEOUT)
        else:
            conn = httplib.HTTPSConnection(proxyhost, proxyport,
                                           timeout=BMC_DEL_TIMEOUT)
            tunnel_header = {}
            # tunnel_header['Proxy-Connection'] = 'Keep-Alive'
            conn.set_tunnel(netloc, 443, tunnel_header)

            # if debug:
            #  conn.set_debuglevel(2)

        path = ("/n/%s/b/%s/o/%s" % (p.namespace, container, filename))

        # BMC headers needs to be specified for each REQUEST separately
        del_headers = set_bmc_headers(p, "DELETE", netloc, path)

        if debug:
            with ctx.loglock:
                log_msg("bmc_delete_request: Requesting " + netloc + path)

        conn.request("DELETE", path, None, del_headers)
        r1 = conn.getresponse()
        if r1.status >= 400:
            with ctx.loglock:
                log_msg("bmc_delete_request: Error from " + netloc +
                        path + ", status: " + str(r1.status))
            conn.close()
            return 1
        elif debug:
            with ctx.loglock:
                log_msg("bmc_delete_request: Response from " +
                        netloc + path + ", status: " + str(r1.status))

        with ctx.loglock:
            log_msg(r1.read())
        conn.close()

    return 0


#
# cloud_listfilechunk - list chunk file names with chunkprefix
#
#
# Parameters
#   - thread context
#   - odbs context 
#   - container name of the file chunk
#   - chunk prefix, ?prefix option in GET request, used to reduce unnecessary HTTPS response
#   - output list of chunk names
#   - metadata XML file name list ptr
def cloud_listfilechunk(ctx, p, con, chunkprefix, chunklist):

    for ii in range(0, RETRY):
        del chunklist[:]
        rc = opc_listfilechunk(ctx, p, con, chunkprefix, chunklist)
        if rc == 0:
            break
        elif ii < (RETRY - 1):
            with ctx.loglock:
                log_msg("cloud_listfilechunk: Failed to list chunks" +
                        "%s, RETRYING..." % chunkprefix)

    return rc

#
# opc_listfilechunk - list chunk file names with chunkprefix
#
#
# Parameters
#   - thread context
#   - odbs context 
#   - container name of the file chunk
#   - chunk prefix, ?prefix option in GET request, 
#                   used to reduce unnecessary HTTPS response
#   - output list of chunk names
def opc_listfilechunk(ctx, p, container, chunkprefix, chunklist):

    headers = p.headers
    host    = p.host
    proxyhost = p.proxyhost
    proxyport = p.proxyport
    debug     = p.debug

    if not isinstance(chunklist, list):
        with ctx.loglock:
            log_msg("opc_listfilechunk: Internal Error, NULL or " +
                    "NON-LIST chunklist")
        exit(1)

    o = urlparse.urlparse(host)
    marker = None
    start  = None

    while True:
        netloc = o.netloc
        path = o.path

        if proxyhost is None:
            conn = httplib.HTTPSConnection(netloc, timeout=LIST_TIMEOUT)
        else:
            conn = httplib.HTTPSConnection(proxyhost, proxyport,
                                           timeout=LIST_TIMEOUT)
            #conn.set_debuglevel(2)
            tunnel_header = {}
            #tunnel_header['Proxy-Connection'] = 'Keep-Alive'
            conn.set_tunnel(netloc, 443, tunnel_header)

        if p.cred.isbmcbased():
            if start is None:
                #path = ("/n/%s/b/%s/o?limit=%d&prefix=%s" %
                #        (p.namespace, container, BMC_LIMIT, chunkprefix))
                options = {'limit': BMC_LIMIT,
                           'prefix': chunkprefix}
            else:
                #path = ("/n/%s/b/%s/o?limit=%d&prefix=%s&start=%s" %
                #        (p.namespace, container, BMC_LIMIT, chunkprefix, start))
                options = {'limit': BMC_LIMIT,
                           'prefix': chunkprefix,
                           'start': start}

            path = "/n/%s/b/%s/o?%s" % (p.namespace, container,
                                        urllib.urlencode(options))

            # BMC headers needs to be specified for each REQUEST separately
            headers = set_bmc_headers(p, "GET", netloc, path)
        else:
            if marker is None:
                #path = (path + "/" + container +
                #        "/?format=xml&limit=" + str(LIMIT) +
                #        "&prefix=" + chunkprefix)
                options = {'format': 'xml',
                           'limit': LIMIT,
                           'prefix': chunkprefix}

            else:
                #path = (path + "/" + container +
                #        "/?format=xml&limit=" + str(LIMIT) +
                #        "&prefix=" + chunkprefix + "&marker=" + marker)
                options = {'format': 'xml',
                           'limit': LIMIT,
                           'prefix': chunkprefix,
                           'marker': marker}
            path = "%s/%s/?%s" % (path, container, urllib.urlencode(options))

        if debug:
            with ctx.loglock:
                log_msg("opc_listfilechunk: Requesting " + netloc + path)

        conn.request("GET", path, None, headers)
        r1 = conn.getresponse()
        if r1.status >= 400:
            with ctx.loglock:
                log_msg("opc_listfilechunk: Error from " + netloc + path +
                        ", status: " + str(r1.status))
            conn.close()
            return 1
        elif debug:
            with ctx.loglock:
                log_msg("opc_listfilechunk: Response from " + netloc + path +
                        ", status: " + str(r1.status))

        objects = r1.read()
        conn.close()

        if p.cred.isbmcbased():
            output = json.loads(objects)
            start = output.get("nextStartWith")
            objects_list = output.get("objects")

            if debug:
                with ctx.loglock:
                    log_msg("opc_processcontainer_auxlist_int: nextSTART=%s" % start)

            if len(objects_list) == 0:
                break

            for obj in objects_list:
                name = obj.get("name")

                chunklist.append(name)

                if debug:
                    with ctx.loglock:
                        log_msg("opc_listfilechunk:    %s" % name)

            if start is None:
                break
        else:
            root = ET.fromstring(objects)

            if root.find("object") is None:
                break

            for f in root.findall("object"):
                name = f.find("name").text
                last_mod = f.find("last_modified").text
                marker = name

                chunklist.append(name)

                if debug:
                    with ctx.loglock:
                        log_msg("opc_listfilechunk:    %s" % name)

    return 0

#
# cloud_downloadXMLs - downloads metadata.xml contents
#
#
# Parameters
#   - thread context ptr
#   - odbs context ptr
#   - file name to be downloaded
#   - container name of the file
#   - output metadata content object ptr
def cloud_downloadXMLs(ctx, p, file, con, pc_metadata_ptr):

    if not isinstance(pc_metadata_ptr, list):
        with ctx.loglock:
            log_msg("cloud_downloadXMLs: Internal Error, NULL or " +
                    "NON-LIST pc_metadata_ptr")
            exit(1)

    for ii in range(0, RETRY):
        xmlstr_ptr = [0]
        rc = opc_downloadXMLs(ctx, p, file, con, xmlstr_ptr)

        if rc == 1:
            if ii < (RETRY - 1):
                with ctx.loglock:
                    log_msg("cloud_downloadXMLs: Failed to download " +
                            "%s, RETRYING..." % file)
            continue

        # parse xmlstr
        xmlstr = xmlstr_ptr[0]

        # initialize metadata object
        pc_metadata = PieceMetaData()

        try:
            root = ET.fromstring(xmlstr)

            f = root.find("Database")
            if f is not None:
                fb = f.find("Dbname")
                if fb is not None:
                    pc_metadata.dbname = fb.text
                fb = f.find("Dbid")
                if fb is not None:
                    pc_metadata.dbid = fb.text
                fb = f.find("DbVersion")
                if fb is not None:
                    pc_metadata.dbverion = fb.text
            else:
                with ctx.loglock:
                    log_msg("cloud_downloadXMLs: %s missing Database tag" % file)

            f = root.find("File")
            if f is not None:
                fa = f.find("FileName")
                if fa is not None:
                    pc_metadata.filename = fa.text
                fa = f.find("FileSize")
                if fa is not None:
                    pc_metadata.filesize = fa.text
                fa = f.find("LastModified")
                if fa is not None:
                    pc_metadata.lastmodified = fa.text
                fa = f.find("ChunkPrefix")
                if fa is not None:
                    pc_metadata.chunkprefix = fa.text
                ff = f.find("Property")
                if ff is not None:
                    fx = ff.find("BackupType")
                    if fx is not None:
                        pc_metadata.backuptype = fx.text
                    fx = ff.find("Incremental")
                    if fx is not None:
                        pc_metadata.incremental = fx.text
                    fx = ff.find("Compressed")
                    if fx is not None:
                        pc_metadata.compressed = fx.text
                    fx = ff.find("Encrypted")
                    if fx is not None:
                        pc_metadata.encrypted = fx.text
                    fx = ff.find("SetStamp")
                    if fx is not None:
                        pc_metadata.setstamp = fx.text
                    fx = ff.find("SetCount")
                    if fx is not None:
                        pc_metadata.setcount = fx.text
                    fx = ff.find("PieceNo")
                    if fx is not None:
                        pc_metadata.pieceno = fx.text
            else:
                with ctx.loglock:
                    log_msg("cloud_downloadXMLs: Error, %s missing File tag"
                            % file)
                # file does not have File TAG info, no need to RETRY
                # return 1 and skip this backup piece
                return 1

            if rc == 0:
                break

        except ET.ParseError as e:
            with ctx.loglock:
                log_msg("cloud_downloadXMLs: %s" % str(e))
            if ii < (RETRY - 1):
                with ctx.loglock:
                    log_msg("cloud_downloadXMLs: ElementTree.ParseError of %s, RETRYING..."
                            % file)
            else:
                with ctx.loglock:
                    log_msg("cloud_downloadXMLs: Failure, ElementTree.ParseError of %s"
                            % file)
                return 1

            continue

    if rc == 1:
        return 1

    # for each file a date check is performed again(if date check is not passed, then
    # it means there's error since datecheck was performed in the list object phase)
    if not piece_datecheck(pc_metadata.lastmodified, p.untildate, file, p.debug):
        with ctx.loglock:
            log_msg("cloud_downloadXMLs: WARNING, BACKUP PIECE %s timestamp" % file +
                    " is inconsistent with oracle cloud timestamp")
        pc_metadata_ptr[0] = None
        return 0

    pc_metadata_ptr[0] = pc_metadata

    return 0

#
# opc_downloadXMLs - downloads metadata.xml contents
#
#
# Parameters
#   - thread context ptr
#   - odbs context ptr
#   - file name to be downloaded
#   - container name of the file
#   - output metadata content object ptr
def opc_downloadXMLs(ctx, p, file, container, xmlstr_ptr):

    headers = p.headers
    host    = p.host
    proxyhost = p.proxyhost
    proxyport = p.proxyport
    debug   = p.debug

    if not isinstance(xmlstr_ptr, list):
        with ctx.loglock:
            log_msg("opc_downloadXMLs: Internal Error, NULL or " +
                    "NON-LIST xmlstr_ptr")
            exit(1)

    o = urlparse.urlparse(host)

    netloc = o.netloc
    path = o.path

    if proxyhost is None:
        conn = httplib.HTTPSConnection(netloc, timeout=DOWNLOAD_TIMEOUT)
    else:
        conn = httplib.HTTPSConnection(proxyhost, proxyport,
                                       timeout=DOWNLOAD_TIMEOUT)
        #conn.set_debuglevel(2)
        tunnel_header = {}
        tunnel_header['Proxy-Connection'] = 'Keep-Alive'
        conn.set_tunnel(netloc, 443, tunnel_header)

    if p.cred.isbmcbased():
        path = "/n/%s/b/%s/o/%s" % (p.namespace, container, file)
        # BMC headers needs to be specified for each REQUEST separately
        headers = set_bmc_headers(p, "GET", netloc, path)
    else:
        path = "%s/%s/%s" % (path, container, file)

    if debug:
        with ctx.loglock:
            log_msg("opc_downloadXMLs: Requesting " + netloc + path)

    conn.request("GET", path, None, headers)
    r1 = conn.getresponse()
    if r1.status >= 400:
        with ctx.loglock:
            log_msg("opc_downloadXMLs: Error from " + netloc + path +
                    ", status: " + str(r1.status))
        conn.close()
        return 1
    elif debug:
        with ctx.loglock:
            log_msg("opc_downloadXMLs: Response from " + netloc + path +
                    ", status: " + str(r1.status))

    outputstr = r1.read()
    conn.close()

    xmlstr_ptr[0] = outputstr

    return 0

#
# cloud_report- main function
#               when mode=report/rman-listfile, write output to file handle
#               when mode=delete/garbage-collection, create delete list that
#               contains a list of backup pieces metdata data
#               By default, report/rman-listfile mode skips heartbeat metadata
#               delete mode includes heartbeat metadata unless
#               exclude_deferred is specified
#               garbage-collection mode always include heartbeat data
#               when mode=recall, send GET request to retrieve all file chunks
#
def cloud_report(p):

    if p.forcename is not None:
        fbasename = get_log_file_name(p.dir, p.forcename, p.debug)
    elif p.base is not None:
        fbasename = (get_log_file_name(p.dir, p.base, p.debug) +
                     str(os.getpid()))
    cred = p.cred
    host = p.host
    container = p.container
    mode = p.mode
    exclude_deferred = p.exclude_deferred
    format = p.format
    bpprefix = p.bpprefix
    dbid  = p.dbid
    untildate = p.untildate
    maxthread = p.thread
    proxyhost = p.proxyhost
    proxyport = p.proxyport
    debug     = p.debug

    textformat = False
    jsonformat = False
    xmlformat  = False
    if (format == "text") or (format is None):
        textformat = True
    elif format == "xml":
        xmlformat = True
    elif format == "json":
        jsonformat = True
    else:
        textformat = True

    txttemplate = "%-30s\n%-25s%-15s%-12s%-18s%-28s%-28s%-13s%-13s%-12s\n"

    report         = True if mode == 'report' else False
    rmanlistfile   = True if mode == 'rman-listfile' else False
    garbagecollect = True if mode == 'garbage-collection' else False
    delete         = True if mode == 'delete' else False
    recall = True if mode == 'recall' else False

    # By default, report mode skips heartbeat metadata
    # delete mode includes heartbeat metadata unless
    # exclude_deferred is specified
    if report or rmanlistfile or recall:
        include_heartbeat = False
    elif garbagecollect:
        include_heartbeat = True
    elif exclude_deferred:
        include_heartbeat = False
    else:
        include_heartbeat = True

    headers = {}

    if cred.ispasswordbased():
        user = cred.username
        password = cred.password
        headers["Authorization"] = "Basic " + base64.b64encode(user+":"+password)
        headers["Accept"] = '*/*'
    elif cred.istokenbased():
        token = cred.token
        headers["X-Auth-Token"] = token
        headers["Accept"] = '*/*'

    p.headers = headers

    # validate cloud end point
    rc = cloud_validate(p)

    if rc == 1:
        log_msg("odbsrmt.py: Unexpected error in cloud_validation, quit...")
        exit(1)

    if cred.isbmcbased():
       rc = cloud_getnamespaceinfo(p)

       if rc == 1:
           log_msg("odbsrmt.py: Unexpected error in cloud_validation, quit...")
           exit(1)

    # Initialize containerlist
    containerlist=[]

    if container is not None:
        containerlist.append(container)
    else:
        log_msg("odbsrmt.py: Getting container list...")
        rc = cloud_getcontainers(p, containerlist)
        if rc == 1:
            log_msg("cloud_report: Failed to get container list")
            exit(1)

    # initialize backuppiece Queue, each element is a Bkplist object
    # this queue is used then for mutl-thread consumption
    backuppiece_queue = Queue.Queue()

    for con in containerlist:
        log_msg("odbsrmt.py: Processing container %s..." % con)

        backuppiecelist_single = []

        rc = cloud_processcontainer(p, con, include_heartbeat, 
                                    garbagecollect,
                                    backuppiecelist_single)
        if rc == 1:
            log_msg("cloud_report: WARNING! Failed to scan container " +
                    "%s, try next..." % con)
            continue

        for pcname in backuppiecelist_single:
            elem = Bkplist(pcname, con)
            backuppiece_queue.put(elem)

    if backuppiece_queue.empty():
        log_msg("cloud_report: No qualifying backup piece found, quit")
        exit(0)

    # In report or rman-listfile mode, we will only generate ONE output file
    # initialize the file handle now
    fh = None
    if report or rmanlistfile or recall:
        if not p.forcename:
            filename = fbasename + p.ext
        else:
            filename = fbasename
        fh = open(filename, 'w')

        if report:
            if textformat:
                # print text format list header
                fh.write(txttemplate % ("FileName", "Container", "Dbname", "Dbid",
                                        "FileSize", "LastModified",
                                        "BackupType", "Incremental", "Compressed",
                                        "Encrypted"))
            elif xmlformat:
                fh.write("<?xml version=\"1.0\" encoding=\"US-ASCII\"?> \n")
                fh.write("<MetaData>\n")
            elif jsonformat:
                fh.write("{\"MetaData\": {\n\"File\": [\n")
        elif rmanlistfile or recall:
            # if rmanlistfile, only XML then
            fh.write("<?xml version = \"1.0\" encoding=\"US-ASCII\"?> \n")
            fh.write("<MetaData>\n")

    # initialize threadpool
    threadpool=[0 for ii in range(maxthread)]

    # initialize queue for calculating backup piece size sums
    calculatesize_queue = Queue.Queue()

    # initialize ThreadCtx
    threadctx = ThreadCtx(backuppiece_queue, fh, calculatesize_queue)

    for jth in range(0, maxthread):
        threadpool[jth]=threading.Thread(target=cloud_slave_processors,
                                         args=("Thread_"+str(jth), threadctx,
                                               p))
        threadpool[jth].start()

    for jth in range(0, maxthread):
        threadpool[jth].join()

    # loop through calculatesize_queue to sum size
    totalbyte = 0
    while not calculatesize_queue.empty():
        totalbyte = totalbyte + calculatesize_queue.get()

    # After all slaves have done, print tail characters to finish doc
    if report:
        totalgb = float(totalbyte)/1024/1024/1024
        # keep two decimals
        totalgb = round(totalgb, 2)
        if textformat:
            fh.write("Total Storage: %.2f GB\n" % totalgb)
        elif xmlformat:
            fh.write("   <TotalStorage>%.2fGB</TotalStorage>\n" % totalgb)
            fh.write("</MetaData>\n")
        elif jsonformat:
            fh.write("   ],\n")
            fh.write("   \"TotalStorage\": \"%.2fGB\"\n" % totalgb)
            fh.write("}}")
    elif rmanlistfile or recall:
        # if rmanlistfile, only XML then, no need to print Storage
        fh.write("</MetaData>\n")

    if fh is not None:
       fh.close()

    return



if __name__ == "__main__":

    parser = argparse.ArgumentParser()

    parser.add_argument("--mode",
                        required=True,
                        choices=['report','rman-listfile', 
                                 'garbage-collection', 'delete', 'recall'],
                        help='''be one of the keyword 'report', 'rman-listfile',
                                'delete', 'garbage-collection' or 'recall'.
                                Report mode lists all metadata information about
                                backup pieces. Rman-listfile mode generates
                                backup location list file in XML format that
                                can be read by RMAN to perform DUPLICATE/
                                RESTORE/CATALOG. Delete mode removes 
                                certain backup pieces in one operation
                                and --dbid must be provided. Backup pieces 
                                associated with dbid will be deleted.
                                Garbage-collection mode will purge backups
                                that remained due to _OPC_DEFERRED_DELETE. Recall
                                mode triggers the retrieval of backups in 
                                archive storage''')

    parser.add_argument("--ocitype",
                        required=False,
                        choices=['classic','swift','bmc','archive'],
                        help='''be one of the keyword 'classic', 'swift', 'bmc' or 'archive'.
                             ''')

    parser.add_argument("--credential",
                        required=False,
                        help='''username(optional /password; otherwise prompts
                              for password) to connect to OCI''')

    parser.add_argument("--token",
                        required=False,
                        help='''Authentication token''')

    parser.add_argument("--host",
                        required=True,
                        help="OCI end point")

    parser.add_argument("--base",
                        help="output file base name")

    parser.add_argument("--forcename",
                        help="output file name, if a fixed file name is preferred")

    parser.add_argument("--format",
                        choices=['text', 'xml', 'json'],
                        help="format of output file")

    parser.add_argument("--dbid", type=int,
                        help="Database ID that is associated with the backups")

    parser.add_argument("--container", 
                        help="container that stores the backups")

    parser.add_argument("--dir", 
                        help='''directory where the output file will be stored,
                                by default, current directory will be used''')

    parser.add_argument("--prefix", 
                        help='''process only backups with the specified prefix,
                                by default, all files in the containers will
                                be scanned''')

    parser.add_argument("--untildate", 
                        help='''process only backups prior to the 
                                specified date,
                                by default, all files in the containers will
                                be scanned. Must be in YYYY-MM-DD format''')

    parser.add_argument("--exclude_deferred", action='store_true',
                        help='''process only backups prior to the 
                                specified date,
                                by default, all files in the containers will
                                be scanned. Must be in YYYY-MM-DD format''')

    parser.add_argument("--thread", type=int,
                        help="Number of threads to be spawned")

    parser.add_argument("--proxyhost",
                        help="Proxy host name")

    parser.add_argument("--proxyport", type=int,
                        help="Proxy port number")

    parser.add_argument("--tocid",
                        help="Tenancy OCID")

    parser.add_argument("--uocid",
                        help="User OCID")

    parser.add_argument("--pubfingerprint",
                        help="Public Key Fingerprint")

    parser.add_argument("--pvtkeyfile",
                        help="RSA Private Key File")

    parser.add_argument("--skip_check_status", action='store_true',
                        help='''skip checking job status step 
                                when RECALL requests are done''')

    parser.add_argument("--debug", action='store_true', 
                        help='''turns on production of debugging info''')

    
    args = parser.parse_args()

    # initialize arg context
    p = Odbs_context()

    p.debug       = args.debug
    p.dir         = args.dir
    p.base        = args.base
    p.forcename   = args.forcename
    p.mode        = args.mode
    p.host        = args.host
    p.container   = args.container
    p.exclude_deferred = args.exclude_deferred
    p.format      = args.format
    p.bpprefix    = args.prefix
    p.dbid        = args.dbid
    p.untildate   = args.untildate
    p.thread      = args.thread
    p.ocitype     = args.ocitype
    p.proxyhost   = args.proxyhost
    p.proxyport   = args.proxyport
    p.uocid       = args.uocid
    p.tocid       = args.tocid
    p.fingerprint = args.pubfingerprint
    p.pvtkeyfile  = args.pvtkeyfile
    p.skip_check_status = args.skip_check_status

    if p.ocitype is None:
        p.ocitype = 'classic'
    elif p.ocitype == 'bmc':
        from Crypto.PublicKey import RSA
        from Crypto.Signature import PKCS1_v1_5
        from Crypto.Hash import SHA256
        #import httpsig

    # if you do recall, then assuming you are playing with archive storage
    if p.mode == 'recall':
        p.ocitype = 'archive'

    # check base and forcename option
    if (p.base is None) and (p.forcename is None):
        log_msg("odbsrmt.py: Either --base or --forcename must be specified")
        exit(1)
    elif (p.base is not None) and (p.forcename is not None):
        log_msg("odbsrmt.py: Cannot specifiy both --base and --forcename")
        exit(1)

    if ((p.proxyhost is None and p.proxyport is not None) or
        (p.proxyhost is not None and p.proxyport is None)):
        log_msg("odbsrmt.py: Must specifiy both --proxyhost and --proxyport")
        exit(1)

    # check --untildate format
    if p.untildate is not None:
        rc = validate_date(p.untildate)
        if rc == 1:
            exit(1)

    # check dir option
    if p.dir is not None:
        rc = valid_log_dir(p.dir)
        if rc == 1:
            log_msg("odbsrmt.py: Directory %s is invalid" % p.dir)
            exit(1)

    if p.ocitype == 'classic' or p.ocitype == 'swift' or p.ocitype == 'archive':
        if args.credential is None and args.token is None:
            log_msg("odbsrmt.py: credential or token must be specified")
            exit(1)
    elif p.ocitype == 'bmc':
        if not (args.tocid and args.uocid
                and args.pubfingerprint
                and args.pvtkeyfile):
            log_msg("odbsrmt.py: BMC authentication information must be specified")
            exit(1)

    if args.token is not None:
        p.cred = get_login_token(args.token)
    elif (args.tocid and args.uocid
          and args.pubfingerprint
          and args.pvtkeyfile):
        p.cred = get_login_keyid(p)
    else:
        # get cred object
        p.cred = get_login_string(args.credential)
        if (len(p.cred.username) == 0):
           log_msg('odbsrmt.py: credential, token or BMC auth info must be specified')
           exit(1)

    # remove trailing slash in host if any
    p.host = p.host.rstrip("/")

    # check thread option
    if (p.thread is None) or (p.thread <= 0):
        p.thread = 1

    if p.mode == 'delete':
        if p.dbid is None:
            log_msg("odbsrmt.py: Dbid must be provided")
            exit(1)

    if p.mode == 'rman-listfile' or p.mode == 'recall':
        p.format = 'xml'

    p.ext = ".lst"

    if (p.format == "text") or (p.format is None):
        p.ext = ".lst"
    elif p.format == "xml":
        p.ext = ".xml"
    elif p.format == "json":
        p.ext = ".json"
    else:
        p.ext = ".lst"

    if p.forcename is not None:
        ReportFileBaseName = get_log_file_name(p.dir, p.forcename, p.debug)
        p.ext = ''
    elif p.base is not None:
        ReportFileBaseName = (get_log_file_name(p.dir, p.base, p.debug) +
                              str(os.getpid()))

    if p.mode == "report" or p.mode == "rman-listfile" or p.mode == "recall":
        log_msg("odbsrmt.py: ALL outputs will be written to [%s]"
                 % (ReportFileBaseName + p.ext))
    else:
        log_msg("odbsrmt.py: ALL outputs will be written to [%s_*%s]"
                 % (ReportFileBaseName,  p.ext))

    # main routine to construct backup metadata output
    cloud_report(p)

    if p.mode == "report" or p.mode == "rman-listfile" or p.mode == "recall":
        log_msg("odbsrmt.py: ALL outputs have been written to [%s]"
                 % (ReportFileBaseName + p.ext))
    else:
        log_msg("odbsrmt.py: ALL outputs have been written to [%s_*%s]"
                 % (ReportFileBaseName,  p.ext))
