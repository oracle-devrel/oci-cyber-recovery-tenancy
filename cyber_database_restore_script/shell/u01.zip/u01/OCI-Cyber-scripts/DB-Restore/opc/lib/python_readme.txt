Backup on the Oracle Cloud - Using the Oracle Database Cloud Backup Utility
Tools 

This is the README file for utility tool scripts that support 
Oracle Database Cloud Backup Module to back up an Oracle database to
Oracle Database Backup Service (ODBS) (also referred to as
 Oracle Cloud Infrastructure(OCI) in this document).

--------------------------------------------------------------------
I. What you need to have before starting the installation

Using these tools require an Oracle Database Backup
Service account, and the software library and associated
files. Before you run the tool, verify that you have:

1. Your Oracle Database Backup Service Username, Password
   and Hostname

   You obtain these credentials at https://cloud.oracle.com.

2. The python script: odbsrmt.py

   The installer will download the scripts together with the 
   library. 

4. Python 2, with version 2.7 on the computer where the tools will run.

5. Database Version Support: The Oracle Database Cloud Backup Module
   can be used to backup the following supported versions of Oracle
   Database: Oracle Database 10g Release 2 or higher.

6. odbsrmt.py does not require a running database or Oracle 
   Database Cloud Backup Module.

7. The scripts do not support Windows platform.

--------------------------------------------------------------------
II. User Guide for odbsrmt.py: options description 

Odbsrmt.py is a python based tool that reports and maintains the 
cloud backups. It can be a handy tool to list all backup metadata 
within a container or remove certain backups once the database has
been dropped but backups still remain in cloud. If a deferred-delete
option is turned on, odbsrmt.py offers a mode to perform garbage 
collection. odbsrmt.py is also the tool to generate backup list
file that provides RMAN a way to catalog/duplicate/restore from
cloud backups. In addition, odbsrmt.py supports RECALL mode that
is able to retrieve backups from OCI archive storage.

Execute the script supplying all the mandatory parameters in one
line, each double-hyphen-preceded label followed by '=' and its value
(if a value is required).

First run the script with help option or without any parameters:

 % python odbsrmt.py --help 

to get a usage message, whose parameters are explained below. From
the preceding section, you should have the values for all the
mandatory parameters. Ensure you have python 2 correctly defined.  

    --host:          Host name for the OCI account.
                 
      The host path is mandatory. For example, in OCI Classic, host looks
      like:
      https://[IdentityDomain].storage.oraclecloud.com/v1/[IdentityDomian]

    --credential:    The useranme/password
                     for the Oracle Cloud Storage account

    --token:         Token for authentication if token based login
                     is preferred   

      The credentials/token are mandatory in OCI-classic, SWIFT and Archive Storage.

    --uocid:           User OCID in BMC

    --tocid:           Tenancy OCI in BMC

    --pubfingerprint:  BMC public key fingerprint

    --pvtkeyfile:      BMC private key file path

      If backups are in BMC, --uocid/--tocid/--pubfingerprint/--pvtkeyfile options 
      are all required.

    --container:     OCI container to store backups
                     The name of the container to store backups. 

      The container name is optional. If omitted, all contianers under the 
      host account will be included. 

    --base:      User defined report file base name
    --forcename: This option forces the output file name without appending
                 process ID.

      The output file name will be the base name suffixed with a process id 
      if --base is specified.
      You must specify either --base or --forcename.

    --dir:     The directory to store the report file 
    
      This is optional. If omitted, current directory will be used.

    --mode:    The mode of the script from one of "report", 
               "rman-listfile", "delete", "garbage-collection"
               or "recall"

               report mode lists all metadata information about backup pieces 
               stored in OCI.
 
               rman-listfile mode generates a list file used for RMAN
               FROM FILE option.

               delete mode removes certain backup pieces in one operation.
               --dbid must be provided. 
               Backup pieces associated with the dbname and/or dbid will be 
               deleted.

               garbage collection mode removes expired heartbeat metadata
               in one operation.

               recall mode retrieves archived backup files and checks the
               status until all files are ready or a maximum timeout is
               reached.
            
      This is a mandatory option.

    --ocitype: The type be one of "classic", "swift", "bmc", "archive"

      The default type is "classic"            

    --format:  Format of the report file. When mode=report, can be either
               "json", "xml" or "text". Default is "text" format in report
               mode. Default is "xml" in "rman-listfile" mode. 
  
    --dbid:   Specifies the database ID that is associated with the backup 
              pieces. 

    --prefix: Prefix name of backup pieces. 
              If specified, odbsrmt.py processes only files 
              with the specified prefix.

    --untildate: Filters backup pieces prior to the specified date. 
                 Must be in YYYY-MM-DD format. 


    --exclude_deferred: Ignore backups that are deleted by RMAN when
                        _OPC_DEFERRED_BACKUP is set to TRUE but still 
                        exists in OCI container.

      By default, report/rman-listfile/recall mode skips heartbeat metadata 
      while delete/garbage-collection mode includes heartbeat metadata 
      unless exclude_deferred is specified.
      This is optional.

    --thread: Specifies number of threads that processes the backups.
           
      This option is strongly recommended if a large number of backups are
      expected to be reported or deleted.

    --proxyhost: Specifies the proxy host name if proxy is required to connect
                 to host.

    --proxyport: Specifies the proxy port number if proxy is required to connect
                 to host.

    --skip_check_status: In RECALL mode, skip the status check step and
                         return immediately after recall requests are sent.

    --debug: Provide debug information
    

--------------------------------------------------------------------
VI. User Guide for odbsrmt.py: reports, deletes or recalls cloud backups 

Odbsrmt.py does not require a running Oracle Database. A stand-alone
script is enough to perform the jobs.

1. To list backup information in a certain container in a json formatted
   output file:
python odbsrmt.py --mode=report --credential=username/passwd
--host=https://storage.oraclecorp.com/v1/domainname
--container=backup --base=odbstest --dir=/report-opc/
--format=json --thread=2

For example, this will spawn 2 slave processes to download the metadata 
and will result in an output file of /report-opc/odbstest12345.json.

Metadata like backup piece name, file size, time stamps etc. are recorded in
the output.


2. To delete backups in a certain container associated with some dbid: 
python odbsrmt.py --mode=delete --credential=username/passwd
--host=https://storage.oraclecorp.com/v1/domainname
--container=backup --base=odbstest --dir=/report-opc/
--dbid=81234567 --thread=2

For example, this will result in an output file of /report-opc/odbstest12345.lst.
This file will record all the files that has been deleted by odbsrmt.pl.

3. To generate list XML file for RMAN DUPLCIATE/CATALOG via cloud:
python odbsrmt.py --mode=rman-listfile --credential=username/passwd
--host=https://storage.oraclecorp.com/v1/domainname
--container=backup --forcename=listfile.xml --dir=/report-opc/
--dbid=81234567

For example, this will result in an output file of /report-opc/listfile.xml.
You can point RMAN to this file for database duplication or catalog backups
via cloud.

4. To perform garbage collection in a certain container: 
python odbsrmt.py --mode=garbage-collection --credential=username/passwd
--host=https://storage.oraclecorp.com/v1/domainname
--container=backup --base=odbstest --dir=/report-opc/

For example, this will result in an output file of /report-opc/odbstest12345.lst.
This file will record all the files that has been deleted by odbsrmt.py.

5. To perform recall in archive storage:
python odbsrmt.py --mode=recall ocitype=archive --credential=username/passwd
--host=https://storage.oraclecorp.com/v1/domainname
--container=backup --base=odbstest --dir=/report-opc/
--dbid=81234567 --prefix=test

For example, this will result in an output file of /report-opc/odbstest12345.lst.
All related backup pieces will be recalled, followed by a status check until
all files are ready.

6. To list backup information in a certain container in xml format in OCI SWIFT
python odbsrmt.py --mode=report --ocitype=swift --credential=username/passwd
--host=https://storage.oraclecorp.com/v1/domainname
--container=backup --base=odbstest --dir=/report-opc/
--dbid=81234567 --prefix=test --untildate=2018-01-01

For example, this will result in an output file of /report-opc/odbstest12345.lst.
All related backup pieces will be reported, and only includes backup pieces
with prefix "test" and those created prior to 2018-01-01. 



