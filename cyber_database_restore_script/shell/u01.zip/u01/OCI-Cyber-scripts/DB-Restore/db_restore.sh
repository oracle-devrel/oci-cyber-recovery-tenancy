#!/bin/bash
#######################################################################################
# $Header: db_restore.sh v0.1 2023/02/02 05:24:41 vivaturi - DB Restore $
#
# NAME
#   db_restore.sh
# FUNCTION
#   This script will call the main scripts which should be executed as opc/root user
# NOTES
# MODIFIED
########################################################################################
sh +x /u01/OCI-Cyber-scripts/DB-Restore/db/db_scripts.sh >> /u01/OCI-Cyber-scripts/DB-Restore/db/logs/db_restore_`date +%Y%m%d%H%M%S`.log
